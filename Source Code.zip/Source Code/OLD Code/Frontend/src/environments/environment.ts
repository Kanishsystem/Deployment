export const environment = {
    production: false,
    BASE_API_URL : ["http://igcdoc.softdigisolutions.com/api/"],
     //BASE_API_URL : ["http://igcdoc.softdigisolutions.com/igcardoc_backend/api/"],
   // BASE_API_URL : ["http://localhost/igcardoc_backend/api/"],
  //  BASE_API_URL : ["http://localhost:8080/api/"],
    ENCRYPT_KEY : "U2FsdGVkX19UaF+q3A91+oCYbkRbDQXmRlCI5hOha0s=",
    RES_REQ_SECURITY : false
}
// "http://ebookapi.softdigisolutions.com/api/", http://134.209.232.225:8080/
// igcdoc.softdigisolutions.com