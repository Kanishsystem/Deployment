import { Component } from '@angular/core';

@Component({
  selector: 'app-smart-model',
  templateUrl: './smart-model.component.html',
  styleUrls: ['./smart-model.component.css']
})
export class SmartModelComponent {

}
