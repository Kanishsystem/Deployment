import { Component } from '@angular/core';

@Component({
  selector: 'app-custom-requisition',
  templateUrl: './custom-requisition.component.html',
  styleUrls: ['./custom-requisition.component.css']
})
export class CustomRequisitionComponent {

}
