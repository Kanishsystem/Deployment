<?php

namespace Site\Controller;

use Core\BaseController;

use Core\Helpers\SmartAuthHelper;
use Core\Helpers\SmartData;
use Site\Helpers\CommanComplaintHelper;
use Site\Helpers\ElectricalHelper;
use Site\Helpers\WorkshopHelper;
use Site\Helpers\MeetRoomHelper;
use Site\Helpers\TemporaryAdvanceHelper;
use Site\Helpers\MeetProposalHelper;
use Site\Helpers\DocumentHelper;
use Site\Helpers\TelephoneHelper;
use Site\Helpers\NetworkHelper;
use Site\Helpers\MbookEntryHelper;
use Site\Helpers\RfidCardHelper;
class MisReportsController extends BaseController
{

    private CommanComplaintHelper $_commanComplaint_helper;
    private ElectricalHelper $_electrical_helper;
    private WorkshopHelper $_workshop_helper;
    private MeetRoomHelper $_meetRoom_helper;
    private TemporaryAdvanceHelper $_temporaryAdvance_helper;
    private MeetProposalHelper $_meetProposal_helper;
    private DocumentHelper $_document_helper;
    private TelephoneHelper $_telephone_helper;
    private NetworkHelper $_network_helper;
    private MbookEntryHelper $_mbookEntry_helper;
    private RfidCardHelper $_rfidCard_helper;
    function __construct($params)
    {
        parent::__construct($params);
        // 
        $this->_commanComplaint_helper = new CommanComplaintHelper($this->db);
        $this->_electrical_helper = new ElectricalHelper($this->db);
        $this->_workshop_helper = new WorkshopHelper($this->db);
        $this->_meetRoom_helper = new MeetRoomHelper($this->db);
        $this->_temporaryAdvance_helper = new TemporaryAdvanceHelper($this->db);
        $this->_meetProposal_helper = new MeetProposalHelper($this->db);
        $this->_document_helper = new DocumentHelper($this->db);
        $this->_telephone_helper = new TelephoneHelper($this->db);
        $this->_network_helper = new NetworkHelper($this->db);
        $this->_mbookEntry_helper = new MbookEntryHelper($this->db);
        $this->_rfidCard_helper = new RfidCardHelper($this->db);
    }


    /**
     * 
     */
    //Complaint REPORT
    public function getComplaintReport()
    {
        $start_date = SmartData::post_data("start_date", "DATE");
        $end_date = SmartData::post_data("end_date", "DATE");
        $subcategory = SmartData::post_select_value("subcategory");

        if (empty($start_date) || empty($end_date)) {
            \CustomErrorHandler::triggerInvalid("Start date and End date are required");
        }

        if (empty($subcategory)) {
            \CustomErrorHandler::triggerInvalid("Subcategory is required");
        }

        $ComplaintReport = $this->_commanComplaint_helper->ComplaintReport($start_date, $end_date, $subcategory);

        $this->response($ComplaintReport);
    }
    //Electrical Complaint REPORT
    public function getElectricalComplaintReport()
    {
        $start_date = SmartData::post_data("start_date", "DATE");
        $end_date = SmartData::post_data("end_date", "DATE");

        if (empty($start_date) || empty($end_date)) {
            \CustomErrorHandler::triggerInvalid("Start date and End date are required");
        }

        $ElectricalComplaintReport = $this->_electrical_helper->ElectricalComplaintReport($start_date, $end_date);

        $this->response($ElectricalComplaintReport);
    }
    //Telephone Complaint REPORT
    public function getTelephoneComplaintReport()
    {
        $start_date = SmartData::post_data("start_date", "DATE");
        $end_date = SmartData::post_data("end_date", "DATE");

        if (empty($start_date) || empty($end_date)) {
            \CustomErrorHandler::triggerInvalid("Start date and End date are required");
        }

        $TelephoneComplaintReport = $this->_telephone_helper->TelephoneComplaintReport($start_date, $end_date);

        $this->response($TelephoneComplaintReport);
    }
    //Network Complaint REPORT
    public function getNetworkComplaintReport()
    {
        $start_date = SmartData::post_data("start_date", "DATE");
        $end_date = SmartData::post_data("end_date", "DATE");

        if (empty($start_date) || empty($end_date)) {
            \CustomErrorHandler::triggerInvalid("Start date and End date are required");
        }

        $NetworkComplaintReport = $this->_network_helper->NetworkComplaintReport($start_date, $end_date);

        $this->response($NetworkComplaintReport);
    }
    //Requisition REPORT
    public function getRequisitionReport()
    {
        $start_date = SmartData::post_data("start_date", "DATE");
        $end_date = SmartData::post_data("end_date", "DATE");

        if (empty($start_date) || empty($end_date)) {
            \CustomErrorHandler::triggerInvalid("Start date and End date are required");
        }

        $RequisitionReport = $this->_workshop_helper->RequisitionReport($start_date, $end_date);

        $this->response($RequisitionReport);
    }
    //MeetingRoomReport REPORT
    public function getMeetingRoomReport()
    {
        $start_date = SmartData::post_data("start_date", "DATE");
        $end_date = SmartData::post_data("end_date", "DATE");
        $subcategory = SmartData::post_select_value("subcategory");

        if (empty($start_date) || empty($end_date)) {
            \CustomErrorHandler::triggerInvalid("Start date and End date are required");
        }

        if (empty($subcategory)) {
            \CustomErrorHandler::triggerInvalid("Subcategory is required");
        }

        $MeetingRoomReport = $this->_meetRoom_helper->MeetingRoomReport($start_date, $end_date, $subcategory);

        $this->response($MeetingRoomReport);
    }
    //TemporaryAdvance REPORT
    public function getTemporaryAdvanceReport()
    {
        $start_date = SmartData::post_data("start_date", "DATE");
        $end_date = SmartData::post_data("end_date", "DATE");

        if (empty($start_date) || empty($end_date)) {
            \CustomErrorHandler::triggerInvalid("Start date and End date are required");
        }

        $TemporaryAdvanceReport = $this->_temporaryAdvance_helper->TemporaryAdvanceReport($start_date, $end_date);

        $this->response($TemporaryAdvanceReport);
    }
    //Committee MOM REPORT
     public function getCommitteeMomReport()
    {
        $start_date = SmartData::post_data("start_date", "DATE");
        $end_date = SmartData::post_data("end_date", "DATE");
        $subcategory = SmartData::post_select_string("subcategory");
        if (empty($start_date) || empty($end_date)) {
            \CustomErrorHandler::triggerInvalid("Start date and End date are required");
        }
        if (empty($subcategory)) {
            \CustomErrorHandler::triggerInvalid("Subcategory is required");
        }
        $CommitteeMomReport = $this->_meetProposal_helper->CommitteeMomReport($start_date, $end_date, $subcategory);
        $this->response($CommitteeMomReport);
    }
    //
    //Document REPORT
     public function getDocumentReport()
    {
        $start_date = SmartData::post_data("start_date", "DATE");
        $end_date = SmartData::post_data("end_date", "DATE");
        // $subcategory = SmartData::post_select_value("subcategory");
        if (empty($start_date) || empty($end_date)) {
            \CustomErrorHandler::triggerInvalid("Start date and End date are required");
        }
        // if (empty($subcategory)) {
        //     \CustomErrorHandler::triggerInvalid("Subcategory is required");
        // }
        $DocumentReport = $this->_document_helper->DocumentReport($start_date, $end_date);
        $this->response($DocumentReport);
    }
      //Mbook Issue REPORT
      /*
     public function getMbookReport()
    {
        $start_date = SmartData::post_data("start_date", "DATE");
        $end_date = SmartData::post_data("end_date", "DATE");
       $file_type = SmartData::post_data("file_type", "STRING");
       $budget_type = SmartData::post_data("budget_type", "STRING");
        $technical_sanction_number = SmartData::post_data("technical_sanction_number", "INTEGER");
        $contact_name = SmartData::post_data("contact_name", "STRING");
        if (empty($start_date) || empty($end_date)) {
            \CustomErrorHandler::triggerInvalid("Start date and End date are required");
        }
        if (empty($file_type)) {
            \CustomErrorHandler::triggerInvalid("file_type is required");
        }
        if (empty($budget_type)) {
            \CustomErrorHandler::triggerInvalid("budget_type is required");
        }
        if (empty($technical_sanction_number)) {
            \CustomErrorHandler::triggerInvalid("technical_sanction_number is required");
        }
        if (empty($contact_name)) {
            \CustomErrorHandler::triggerInvalid("contact_name is required");
        }
        $MbookIssueReport = $this->_mbookEntry_helper->MbookIssueReport($start_date, $end_date ,$file_type, $budget_type, $technical_sanction_number, $contact_name);
        $this->response($MbookIssueReport);
    }
    */
    //Mbook Issue REPORT
    public function getMbookReport()
    {
    $start_date = SmartData::post_data("start_date", "DATE");
    $end_date = SmartData::post_data("end_date", "DATE");
    $file_type = SmartData::post_data("file_type", "STRING");
    $budget_type = SmartData::post_data("budget_type", "STRING");
    $technical_sanction_number = SmartData::post_data("technical_sanction_number", "INTEGER");
    $contact_name = SmartData::post_data("contact_name", "STRING");

    // No validation here, just pass params to helper
    $MbookIssueReport = $this->_mbookEntry_helper->MbookIssueReport($start_date, $end_date, $file_type, $budget_type, $technical_sanction_number, $contact_name);
    $this->response($MbookIssueReport);
    }
    
    //RFID CARD EXPIRY DATE
    public function getRFIDCardExpiryReport()
   {
    $to_date = SmartData::post_data("to_date", "DATE");

    if (empty($to_date)) {
        \CustomErrorHandler::triggerInvalid("to_date is required");
    }

    $rfidReport = $this->_rfidCard_helper->RfidCardExpiryReport($to_date);

    $this->response($rfidReport);
     }
   

}



