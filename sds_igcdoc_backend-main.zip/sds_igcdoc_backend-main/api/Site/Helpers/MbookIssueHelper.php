<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Site\Helpers;

use Core\BaseHelper;
use Core\Helpers\SmartConst;
use Core\Helpers\SmartGeneral;
use Core\Helpers\SmartData;
use Core\Helpers\SmartDateHelper;
use Core\Helpers\SmartFileHelper;
use Core\Helpers\SmartCurl;
use Core\Helpers\SmartPdfHelper;
use Site\view\MbookIssuePdf;

//
use Site\Helpers\TableHelper as Table;

/**
 * Description of Data
 * 
 *  class helps to get the data from post with specified type 
 *
 * @author kms
 */
class MbookIssueHelper extends BaseHelper
{

    const schema = [
        "mbook_number" => SmartConst::SCHEMA_VARCHAR,
        "date_of_issue" => SmartConst::SCHEMA_DATE,
        "title" => SmartConst::SCHEMA_VARCHAR,
        "description" => SmartConst::SCHEMA_TEXT,
        "sd_mt_userdb_id" => SmartConst::SCHEMA_CUSER_ID,
        "app_id" => SmartConst::SCHEMA_INTEGER,
        "app_time" => SmartConst::SCHEMA_CDATETIME,
        "app_remarks" => SmartConst::SCHEMA_VARCHAR,
        "admin_id" => SmartConst::SCHEMA_INTEGER,
        "admin_time" => SmartConst::SCHEMA_CDATETIME,
        "admin_remarks" => SmartConst::SCHEMA_VARCHAR,
        "created_time" => SmartConst::SCHEMA_CDATETIME,
        "status" => SmartConst::SCHEMA_INTEGER,
        "last_modified_by" => SmartConst::SCHEMA_CUSER_ID,
        "last_modified_remarks" => SmartConst::SCHEMA_TEXT,
        "last_modified_time" => SmartConst::SCHEMA_CTIME,
        "doc_loc" => SmartConst::SCHEMA_VARCHAR,
        //
        "file_type" => SmartConst::SCHEMA_STRING,
        "work_order_number" => SmartConst::SCHEMA_VARCHAR,
        "date_of_work_order" => SmartConst::SCHEMA_DATE,
        "work_order_value" => SmartConst::SCHEMA_VARCHAR,
        "budget_type" => SmartConst::SCHEMA_STRING,
        "budget_pin" => SmartConst::SCHEMA_VARCHAR,
        "contact_name" => SmartConst::SCHEMA_VARCHAR,
        "technical_sanction_number" => SmartConst::SCHEMA_VARCHAR,    
        "start_date" => SmartConst::SCHEMA_DATE,
        "end_date" => SmartConst::SCHEMA_DATE,
        "cc_number" => SmartConst::SCHEMA_VARCHAR,
        "pan_number" => SmartConst::SCHEMA_VARCHAR,
        "email" => SmartConst::SCHEMA_VARCHAR,
        "mobile_no" => SmartConst::SCHEMA_INTEGER,
        "wages_count" => SmartConst::SCHEMA_INTEGER,
        "salary_amount" => SmartConst::SCHEMA_INTEGER,


    ];
    /**
     * 
     */
    const validations = [
        "title" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter Title"
            ],
            [
                "type" => SmartConst::VALID_MAX_LENGTH,
                "max" => 1000,
                "msg" => "Title Max character 1000"
            ]
        ],
        // "description" => [
        //     [
        //         "type" => SmartConst::VALID_REQUIRED,
        //         "msg" => "Please Enter Description"
        //     ]
        // ],
        "app_id" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Select Approver"
            ]
        ],
        "status" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter status"
            ]
        ],

        "last_modified_remarks" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter remarks"
            ]
        ],
        "mbook_number" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter mbook_number"
            ]
        ],
        "date_of_issue" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter date_of_issue"
            ]
        ],
        //  "designation" => [
        //     [
        //         "type" => SmartConst::VALID_REQUIRED,
        //         "msg" => "Please Enter designation"
        //     ]
        // ],
         "file_type" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter file_type"
            ]
        ],
        "name_of_work" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter name_of_work"
            ]
        ],
        "work_order_number" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter work_order_number"
            ]
        ],
        "date_of_work_order" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter date_of_work_order"
            ]
        ],
        "work_order_value" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter work_order_value"
            ]
        ],
        "budget_type" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter budget_type"
            ]
        ],
        "budget_pin" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter budget_pin"
            ]
        ],
        "contact_name" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter contact_name"
            ]
        ],
        "technical_sanction_number" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter technical_sanction_number"
            ]
        ],
        "start_date" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter start_date"
            ]
        ],
        "end_date" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter end_date"
            ]
        ],

         "uploaded_file" => [
            [
                "type" => SmartConst::VALID_FILE_REQUIRED,
                "msg" => "Please Upload the Document"
            ],
            [
                "type" => SmartConst::VALID_FILE_TYPE,
                "msg" => "Only pdf is allowed",
                "ext"=>["pdf"]
            ]
        
            ],
        "cc_number" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter cc_number"
            ]
        ],
        "pan_number" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter pan_number"
            ]
        ],
        "email" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter email"
            ]
        ],
        "mobile_no" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter mobile_no"
            ]
        ],
         "wages_count" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter wages_count"
            ]
        ],
         "salary_amount" => [
            [
                "type" => SmartConst::VALID_REQUIRED,
                "msg" => "Please Enter salary_amount"
            ]
        ],

    ];
    // file handling 
   const FILE_FOLDER = "mbookissue";
   const FILE_NAME = "file";
    //
    public function getFullFile($id){
        return self::FILE_FOLDER . DS . $id . DS . self::FILE_NAME;
    }

    /**
     * 
     */
    public function insert(array $columns, array $data)
    {
        return $this->insertDb(self::schema, Table::MBOOK_ISSUE, $columns, $data);
    }
    /**
     * 
     */
    public function update(array $columns, array $data, int $id)
    {
        return $this->updateDb(self::schema, Table::MBOOK_ISSUE, $columns, $data, $id);
    }
    /**
     * 
     */
    public function getAllData($sql = "", $data_in = [], $group_by = "", $count = false)
    {
        $from = Table::MBOOK_ISSUE . " t1 
        INNER JOIN " . Table::USERS . " t2 ON t1.sd_mt_userdb_id = t2.ID";
        $select = ["t1.*,t2.ename as created_by"];
        $order_by = "t1.created_time DESC";
        return $this->getAll($select, $from, $sql, $group_by, $order_by, $data_in, false, [], $count);
    }

    /**
     * 
     */
    public function getOneData($id)
    {
        $from = Table::MBOOK_ISSUE . " t1 
        INNER JOIN " . Table::USERS . " t2 ON t1.sd_mt_userdb_id = t2.ID 
        ";
        $select = ["t1.*,t2.ename as created_by"];
        $sql = "t1.ID=:ID";
        $data_in = ["ID" => $id];
        $group_by = "";
        $order_by = "";
        return $this->getAll($select, $from, $sql, $group_by, $order_by, $data_in, true, []);
    }
    /**
     * 
     */
    public function getElecWithUserID($id)
    {
        $from = Table::MBOOK_ISSUE;
        $select = ["*"];
        $sql = "sd_mt_userdb_id=:ID";
        $data_in = ["ID" => $id];
        $group_by = "";
        $order_by = "";
        return $this->getAll($select, $from, $sql, $group_by, $order_by, $data_in, true, []);
    }
    /**
     * 
     */
    public function deleteOneId($id)
    {
        $from = Table::MBOOK_ISSUE;
        $this->deleteId($from, $id);
    }

    public function getCount($type)
    {
        $sql = "DATE(t1.created_time)=CURRENT_DATE()";
        if ($type == 1) {
            $sql = "MONTH(t1.created_time)=" . SmartGeneral::getMonth();
        } else if ($type == 2) {
            $sql = "YEAR(t1.created_time)=" . SmartGeneral::getYear();
        }
        $data = $this->getAllData($sql, [], "", true);
        return isset($data) ? count($data) : 0;
    }


    public function getCountByYear($year)
    {
        $select = ["COUNT(title) AS mbook_issue, MONTH(last_modified_time) AS month"];
        $from = Table::MBOOK_ISSUE;
        $sql = "YEAR(last_modified_time) =:year";
        $group_by = "MONTH(last_modified_time)";    // No GROUP BY keyword
        $order_by = "month";
        $data_in = ["year" => $year];
        $count = $this->getAll($select, $from, $sql, $group_by, $order_by, $data_in, false, [], false);
        $mbook_issue_count = array_fill(0, 12, 0);
        foreach ($count as $issue) {
            $month = intval($issue->month);
            $issueCount = intval($issue->mbook_issue);
            $mbook_issue_count[$month - 1] = $issueCount;
        }
        $issue_count_by_year = array_values($mbook_issue_count);
        return $issue_count_by_year;
    }


    public function getCountByStatus()
    {
        $sql = "status=10";
        $data = $this->getAllData($sql, [], "", true);
        return isset($data) ? count($data) : 0;
    }
    
    public function generateMbookNumber()
    {
        $prefix = "MCMFCG";
        $departmentCode = "CFED";
        $year = date("Y");

        $from = Table::MBOOK_ISSUE; // Make sure you have this defined in your Table class
        $select = ["COUNT(*) as count"];

        // Count how many were created this year
        $sql = "YEAR(created_time) = YEAR(CURDATE())";

        $result = $this->getAll($select, $from . " t1", $sql, "", "", [], true);
        $count = (int) ($result->count ?? 0) + 1;

        // Pad NN to two digits (e.g., 01, 02...)
        $serialNumber = str_pad($count, 2, '0', STR_PAD_LEFT);

        return "$prefix/$departmentCode/$year/$serialNumber";
    }
    


    public function getAllSelect($sql = "", $data_in = [], $group_by = "", $count = false)
    {
        $from = Table::MBOOK_ISSUE;
        $select = ["ID as value,mbook_number as label"];
        $order_by = "created_time DESC";
        return $this->getAll($select, $from, $sql, $group_by, $order_by, $data_in, false, [], $count);
    }
    
   
    public function generateMbookIssuePdf($id, $data)
     {
    //  Generate HTML from your PDF layout class
    $html = MbookIssuePdf::getHtml($data);
    //  Send HTML to cURL for PDF generation
    // $this->initiate_curl($html, $id);
    // echo $html;
    }


    public function getMbookIssuePath($id)
    {
        return "mbookissue" . DS . $id . DS . "mbookissue.pdf";
    }

   private function initiate_curl($html, $id)
    {
        $data = new \stdClass();
        $data->content = base64_encode($html);
        $curl = new SmartCurl();
        $_output = $curl->post("/taskapi/html_to_pdf", $data);
        $_output_obj = json_decode($_output);
        if (isset($_output_obj->data)) {
            $path = "mbookissue" . DS . $id . DS . "mbookissue.pdf";
            SmartFileHelper::storeFile($_output_obj->data, $path);
        }
    }
    
  public function getCountStatus($status_sql)
    {
        $select = ["COUNT(*) AS total_count"];
        $from = Table::MBOOK_ISSUE;
        $sql = "status IN (" . $status_sql . ")";
        $data = $this->getAll($select, $from, $sql, "", "", [], true);
        return  isset($data->total_count) ? (int)$data->total_count : 0;
    }



}
