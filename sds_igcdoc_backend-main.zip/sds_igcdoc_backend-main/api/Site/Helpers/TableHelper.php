<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Site\Helpers;

/**
 * Description of Data
 * 
 *  class helps to get the data from post with specified type 
 *
 * @author kms
 */
class TableHelper
{

   const  USERS = "sd_mt_userdb";
   const  ROLES = "sd_mt_role";
   const DOCS = "sd_doc_list";
   const DOCS_PERMISSION = "sd_doc_list_permission";
   const DOC_AUTHORS = "sd_doc_authors";
   const TELEPHONE = "sd_telephone";
   const ELECTRICAL = "sd_electrical";
   const NETWORK = "sd_network";
   const MEETROOM = "sd_meetroom";
   const  MECHANICAL = "sd_mechanical";
   const TYPE = "sd_mt_type";
   const USERROLE = "sd_mt_user_role";
   const USEROTP = "sd_mt_user_otp";
   const SITE = "sd_site_settings";
   const FORM = "sd_forms";
   const ACTIVITY = "sd_site_activities";
   const ORGANISATION = "sd_org";
   const MOM = "sd_mom";
   const MOMTYPES = "sd_mom_types";
   const DOCCATEGORY = "sd_doc_category";
   const COMPLAINTTYPES = "sd_complaint_types";
   const COMPLAINTS = "sd_complaints";
   const WORKSHOP = "sd_workshop";
   const ACV_SHUTDOWN = "sd_acv_shutdown";
   const ELECTRICAL_SHUTDOWN = "sd_electrical_shutdown";
   const HOME_IMAGES = "sd_home_images";
   const LICENSE = "sd_license";
   const HOME_FORMS = "sd_homeforms";
   const AWARDS = "sd_awards";
   const MEET_PROPOSAL = "sd_meet_proposal";
   const GALLERY = "sd_gallery";
   const HISTORY = "sd_history";
   const HELPER = "sd_helper";
   //
   const AC_VENTILATION_COMPLAINT = " sd_ac_ventilation_complaint";
   const RADIOLOGICAL_WORK = " sd_radiological_work";
   const RADIOLOGICAL_WORK_SUB = " sd_radiological_work_sub";
   const  TEMPRORARY_ADVANCE = "sd_temporary_advance";
   const MBOOK_ISSUE = " sd_mbook_issue";
   const MBOOK_ENTRY = " sd_mbook_entry";
   //
   const AMDIN_MENU = "sd_admin_menu";
   const ADMIN_MODULES = "sd_admin_modules";
   const ADMIN_MODULE_PERMISSION = "sd_admin_module_permissions";
   const ADMIN_ROLE_PERMISSION = "sd_admin_role_permissions";
   //
   const WORK_PERMIT = "sd_work_permit";
   //
   const RFID_CARD = "sd_rfid_card";
   //
   const SD_IMPORT  = "sd_import";
   //
    const SITE_VISITORS  = "site_visitors";
}
