export const ERRORS = {
    COMMON : "An unknown error has occurred. Try again in a bit! If it persists, contact our Support Team",
    UNDERMANTENANCE : "This Application is Under Maintenance ,If Any Queries Please Contact Administator", 
    SERVER_NOT_AVAILABLE:"Server Not Available... Please check the Network Connections"

}