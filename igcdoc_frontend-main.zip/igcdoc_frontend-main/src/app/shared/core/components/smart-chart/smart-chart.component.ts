import {
  Component,
  ElementRef,
  Input,
  OnInit,
  Renderer2,
  SimpleChanges
} from '@angular/core';
import { Chart } from 'chart.js/auto';
import { Colors } from 'chart.js';
import { SmartChartConfig } from '../../SmartInterfaces/SmartChartInterface';
import { CommonService } from 'src/app/api-services/common/common.service';

@Component({
  selector: 'app-smart-chart',
  templateUrl: './smart-chart.component.html',
  styleUrls: ['./smart-chart.component.css']
})
export class SmartChartComponent implements OnInit {
  public chart: any = [];
  @Input('type') type: any = 'bar';
  @Input('smartConfig') smartConfig: SmartChartConfig;
  @Input('changeData') changeData: string;

  constructor(
    private renderer: Renderer2,
    private el: ElementRef,
    private common: CommonService
  ) {}

  ngOnInit(): void {
    Chart.register(Colors); // Register once on init
  }

  ngAfterViewInit() {
    if (this.smartConfig) {
      const responsive =
        this.smartConfig.responsive && this.smartConfig.responsive === '0'
          ? false
          : true;

      setTimeout(() => {
        this.createChart(this.chartName, responsive);
        this.createChart(this.chartNameMobile, false);
      }, 0);

      const container = this.el.nativeElement.querySelector(
        '.smart-chart-div-mobile'
      );
      if (container) {
        container.scrollLeft = this.common.currentMonth() * 55;
      }
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.smartConfig) {
      const responsive =
        this.smartConfig.responsive && this.smartConfig.responsive === '0'
          ? false
          : true;

      setTimeout(() => {
        this.createChart(this.chartName, responsive);
        this.createChart(this.chartNameMobile, false);
      }, 0);

      const container = this.el.nativeElement.querySelector(
        '.smart-chart-div-mobile'
      );
      if (container) {
        container.scrollLeft = this.common.currentMonth() * 55;
      }
    }
  }

  get chartName() {
    return this.smartConfig && this.smartConfig.name
      ? this.smartConfig.name
      : 'chart-1';
  }

  get chartNameMobile() {
    return this.smartConfig ? this.smartConfig.name + '_mobile' : 'chart-1_mobile';
  }

  createChart(name: string, responsive: boolean) {
    const canvas: HTMLCanvasElement = <HTMLCanvasElement>(
      document.getElementById(name)
    );

    if (this.chart && this.chart[name]) {
      this.chart[name].destroy();
    }

   
    this.smartConfig.dataSet = this.smartConfig.dataSet.map((dataset: any, index: number) => {
     const darkColors = [
  '#ed0cc4',
  '#170ced',
  '#0ced44',
  '#edd30c',
  '#ed0c17',
  '#ed880c'
];

      return {
        ...dataset,
        backgroundColor: dataset.backgroundColor || darkColors[index % darkColors.length],
        borderColor: dataset.borderColor || '#1A252F',
        borderWidth: dataset.borderWidth || 1
      };
    });

    this.chart[name] = new Chart(canvas, {
      type: this.smartConfig.type,
      data: {
        labels: this.smartConfig.labels,
        datasets: this.smartConfig.dataSet
      },
      options: {
        responsive: responsive,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'top',
            labels: {
              usePointStyle: true
            }
          }
        }
      }
    });

    const legendContainer = this.el.nativeElement.querySelector('.chartjs-legend');
    if (legendContainer) {
      legendContainer.classList.add('my-legend');
    }
  }
}
