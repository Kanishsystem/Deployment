import { Component } from '@angular/core';

@Component({
  selector: 'app-smart-new-dash-card',
  templateUrl: './smart-new-dash-card.component.html',
  styleUrls: ['./smart-new-dash-card.component.css']
})
export class SmartNewDashCardComponent {

}
