import { Component } from '@angular/core';

@Component({
  selector: 'app-smart-text',
  templateUrl: './smart-text.component.html',
  styleUrls: ['./smart-text.component.css']
})
export class SmartTextComponent {

}
