import { SmartAllowDirective } from './smart-allow.directive';

describe('SmartAllowDirective', () => {
  it('should create an instance', () => {
    const directive = new SmartAllowDirective();
    expect(directive).toBeTruthy();
  });
});
