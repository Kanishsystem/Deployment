import { Injectable } from '@angular/core';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { SmartTableNewColumnConfig, ExportOptions } from './excel-export.service';

@Injectable({
  providedIn: 'root',
})
export class PdfExportService {
  exportToPdf({
    columns,
    data,
    filename = 'export.pdf',
    sheetTitle = 'Report',
  }: ExportOptions): void {
    const doc = new jsPDF();

    // Title at top
    doc.setFontSize(16);
    doc.text(sheetTitle, 105, 15, { align: 'center' });

    const headers = columns.map((col) => col.title);
    const rows = data.map((item, index) =>
      columns.map((col) =>
        col.type === 'sno' ? index + 1 : item[col.index] ?? ''
      )
    );

    autoTable(doc, {
      head: [headers],
      body: rows,
      startY: 25,
      didDrawPage: (data) => {
        // Date and time in footer
        const pageHeight = doc.internal.pageSize.height || doc.internal.pageSize.getHeight();
        const now = new Date();
        const formattedDate = now.toLocaleString(); // e.g. "5/20/2025, 10:20:30 AM"
        doc.setFontSize(10);
        doc.text(`Generated on: ${formattedDate}`, doc.internal.pageSize.width - 10, pageHeight - 10, {
          align: 'right',
        });
      },
    });

    doc.save(filename);
  }
}

// import { Injectable } from '@angular/core';
// import jsPDF from 'jspdf';
// import autoTable from 'jspdf-autotable';
// import { SmartTableNewColumnConfig, ExportOptions } from './excel-export.service';

// @Injectable({
//   providedIn: 'root',
// })
// export class PdfExportService {
//   exportToPdf({
//     columns,
//     data,
//     filename = 'export.pdf',
//     sheetTitle = 'Report',
//   }: ExportOptions): void {
//     const doc = new jsPDF();

//     // Title
//     doc.setFontSize(16);
//     doc.text(sheetTitle, 105, 15, { align: 'center' });

//     // Date and Time
//     const now = new Date();
//     const formattedDate = now.toLocaleString(); // e.g., "5/20/2025, 10:15:30 AM"
//     doc.setFontSize(10);
//     doc.text(`Generated on: ${formattedDate}`, 105, 22, { align: 'center' });

//     const headers = columns.map((col) => col.title);
//     const rows = data.map((item, index) =>
//       columns.map((col) =>
//         col.type === 'sno' ? index + 1 : item[col.index] ?? ''
//       )
//     );

//     autoTable(doc, {
//       head: [headers],
//       body: rows,
//       startY: 30, // Shift down to make space for date/time
//     });

//     doc.save(filename);
//   }
// }
