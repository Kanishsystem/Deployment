import { Injectable } from '@angular/core';
import * as ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';

export interface SmartTableNewColumnConfig {
  index: string;
  title: string;
  type?: string;
  width?: number | string;
}

export interface ExportOptions {
  columns: SmartTableNewColumnConfig[];
  data: any[];
  filename?: string;
  sheetTitle?: string;
}

@Injectable({
  providedIn: 'root',
})
export class ExcelExportService {
  async exportToExcel({
    columns,
    data,
    filename = 'export.xlsx',
    sheetTitle = 'Sheet1',
  }: ExportOptions): Promise<void> {
    const formattedData = data.map((item, index) =>
      columns.reduce((acc: any, col) => {
        acc[col.index] = col.type === 'sno' ? index + 1 : item[col.index] ?? '';
        return acc;
      }, {})
    );

    const headers = columns.map((col) => col.title);
    const rows = formattedData.map((item) => Object.values(item));

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(sheetTitle);

    // Title row
    worksheet.mergeCells(1, 1, 1, headers.length);
    const titleCell = worksheet.getCell('A1');
    titleCell.value = sheetTitle;
    titleCell.font = { bold: true, size: 14 };
    titleCell.alignment = { horizontal: 'center', vertical: 'middle' };
    titleCell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFFF00' },
    };

    // Header row
    worksheet.addRow(headers).eachCell((cell) => {
      cell.font = { bold: true };
    });

    // Set column widths
    columns.forEach((col, i) => {
      worksheet.getColumn(i + 1).width =
        typeof col.width === 'number'
          ? col.width
          : typeof col.width === 'string'
          ? parseInt(col.width, 10) || 15
          : 15;
    });

    // Add data rows
    rows.forEach((row) => worksheet.addRow(row));

    // Write to buffer and save
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });
    saveAs(blob, filename);
  }
}
