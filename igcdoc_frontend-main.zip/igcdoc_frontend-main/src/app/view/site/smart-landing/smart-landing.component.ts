import { Component } from '@angular/core';

@Component({
  selector: 'app-smart-landing',
  templateUrl: './smart-landing.component.html',
  styleUrls: ['./smart-landing.component.css']
})
export class SmartLandingComponent {

}
