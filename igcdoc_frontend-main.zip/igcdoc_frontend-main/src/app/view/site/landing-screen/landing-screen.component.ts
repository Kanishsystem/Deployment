import { Component, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {
  get_api_full_route,
  get_api_route,
} from 'src/app/api-services/api-router';
import { NotifyService } from 'src/app/api-services/common/notify.service';
import { SpinnerService } from 'src/app/api-services/common/spinner.service';
import { SessionStorageServiceService } from 'src/app/api-services/core/session-storage-service.service';
import { SmartapiService } from 'src/app/api-services/smartapi.service';
import { SmartDialogService } from 'src/app/shared/core/services/smart-dialog.service';
import { default_iframe_dialog } from '../helpers/site-defaults';
import * as AOS from 'aos';

@Component({
  selector: 'app-landing-screen',
  templateUrl: './landing-screen.component.html',
  styleUrls: ['./landing-screen.component.css'],
})
export class LandingScreenComponent implements OnDestroy {
  imageUrl = '';
  constructor(
    private route: Router,
    private spinner: SpinnerService,
    private api: SmartapiService,
    private notify: NotifyService,
    private userSession: SessionStorageServiceService,
    private modalService: NgbModal,
    private smartDialog: SmartDialogService
  ) {
    this.imageUrl = get_api_full_route('HOME_IMAGES_GET_ONE_IMAGE');
  }

  // Image data
  imageIds: number[] = []; // Store only image IDs from backend
  currentImageIndex: number = 0;
  currentImageSrc: string;

  // Slides data
  slides: any[] = []; // Will be populated from backend
  currentSlideIndex = 0;

  // Other properties
  activeTab: string = 'main';
  siteSettings: any;
  openCLose: boolean = false;
  cardData: any;
  shutdowndata: any = [];
  mainTab: string = 'main';
  isPdfModalOpen = false;
  private slideshowInterval: any;

  ngOnInit(): void {
    this.loadInitialData();
    this.startSlideshow();
     AOS.init();
  }

  loadInitialData() {
    this.getHomeImagesData();
    this.getSettingsData();
    this.getActivity();
    this.getShutDownData();
  }

  // Image slider functions
  getHomeImagesData() {
    this.api.smartGet('HOME_IMAGES_GET_ALL').subscribe((res: any) => {
      this.imageIds = res.map((item: any) => item.ID);
      this.slides = res.map((item: any, index: number) => ({
        id: item.ID,
        title: item.title || `Slide ${index + 1}`,
        description:
          item.description ||
          ` We specialize in Materials Chemistry and Metal Fuel Cycle research. 
        Our team is committed to innovation, sustainability, and scient `,
      }));

      if (this.imageIds.length > 0) {
        this.getImageUpdate(this.imageIds[0]);
      }
    });
  }

  getImageUpdate(id: number) {
    let url = get_api_route('HOME_IMAGES_GET_ONE_IMAGE_NEW') + '/' + id;
    this.api.smartGet(url).subscribe((res: any) => {
      this.currentImageSrc = 'data:image/jpeg;base64,' + res?.content;
    });
  }

  // Navigation functions
  navigateNext() {
    this.currentSlideIndex = (this.currentSlideIndex + 1) % this.slides.length;
    this.currentImageIndex =
      (this.currentImageIndex + 1) % this.imageIds.length;
    this.getImageUpdate(this.imageIds[this.currentImageIndex]);
    this.resetSlideshowTimer();
  }

  navigatePrevious() {
    this.currentSlideIndex =
      (this.currentSlideIndex - 1 + this.slides.length) % this.slides.length;
    this.currentImageIndex =
      (this.currentImageIndex - 1 + this.imageIds.length) %
      this.imageIds.length;
    this.getImageUpdate(this.imageIds[this.currentImageIndex]);
    this.resetSlideshowTimer();
  }

  goToSlide(index: number) {
    this.currentSlideIndex = index;
    this.currentImageIndex = index % this.imageIds.length;
    this.getImageUpdate(this.imageIds[this.currentImageIndex]);
    this.resetSlideshowTimer();
  }

  // Slideshow control
  startSlideshow(): void {
    this.stopSlideshow();
    this.slideshowInterval = setInterval(() => {
      this.navigateNext();
    }, 5000);
  }

  stopSlideshow(): void {
    if (this.slideshowInterval) {
      clearInterval(this.slideshowInterval);
    }
  }

  resetSlideshowTimer() {
    this.stopSlideshow();
    this.startSlideshow();
  }

  // Other existing functions
  openPdfModal() {
    this.isPdfModalOpen = true;
  }

  closePdfModal() {
    this.isPdfModalOpen = false;
  }

  updateTab(tab: string) {
    this.activeTab = tab;
  }

  getShutDownData() {
    this.api.smartGet('SITE_DASH_SHUTDOWN').subscribe((res: any) => {
      this.shutdowndata = res;
    });
  }

  getSettingsData() {
    this.api.smartGet('AUTH_SITE_SETTINGS').subscribe((res: any) => {
      this.siteSettings = res;
      this.userSession.setSettings(res);
    });
  }

  getActivity() {
    let activity = this.userSession.getActivity();
    if (!activity) {
      this.api.smartGet('ACTIVITY_GET_ALL').subscribe((res: any) => {
        this.cardData = res;
      });
    } else {
      this.cardData = activity;
    }
  }
  openPdfView() {
    const fileUrl = this.siteSettings?.uploaded_file_dpr;
    const options = {
      title: 'DPR',
      iframe: fileUrl,
    };
    const dialog_options = default_iframe_dialog(options);
    dialog_options.width = 90;

    this.smartDialog.openDialog(dialog_options);
  }

  ngOnDestroy(): void {
    this.stopSlideshow();
  }

  openPdfOrg(url) {
    //  let id = data?.ID !== undefined ? data?.ID : 0;
    let options = {
      title: 'PDF Viewer',
      iframe: get_api_route(url),
    };
    let dialog_options = default_iframe_dialog(options);
    dialog_options.width = 90;
    dialog_options.iframe_payload = { id: 1 };
    this.smartDialog.openDialog(dialog_options);
  }
  
}
