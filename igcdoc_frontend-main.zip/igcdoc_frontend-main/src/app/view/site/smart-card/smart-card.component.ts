import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { SessionStorageServiceService } from 'src/app/api-services/core/session-storage-service.service';

@Component({
  selector: 'app-smart-card',
  templateUrl: './smart-card.component.html',
  styleUrls: ['./smart-card.component.css'],
})
export class SmartCardComponent {
  @Input('data') data: any;
  constructor(
    private route: Router,
    private userSession: SessionStorageServiceService
  ) {}

  checkPerm(perm) {
    if (!Array.isArray(perm)) {
      return true;
    }
    // console.log('User Card Data', this.data);
    const userRoleCheck = this.userSession.checkRoleExists(perm);
    return userRoleCheck;
  }
  get cardRoleToShow() {
    const rolePriority = [
      { key: 'hos', check: this.isHos },
      { key: 'rfid', check: this.isRFIDcardIssue },
    ];
    const matched = rolePriority.find((r) => r.check);
    return matched?.key || null;
  }

  get isAdmin() {
    return this.checkPerm(['ADMIN']);
  }

  get isEle() {
    return this.checkPerm(['SD_ELE_ADMIN']);
  }

  get isTp() {
    return this.checkPerm(['SD_TP_ADMIN']);
  }

  get isNw() {
    return this.checkPerm(['SD_NW_ADMIN']);
  }

  get isMe() {
    return this.checkPerm(['SD_MECH_ADMIN']);
  }

  get isDoc() {
    return this.checkPerm(['SD_DOC_ADMIN']);
  }
  get isHos() {
    return this.checkPerm(['SD_SEC_HEAD']);
  }
  get isHod() {
    return this.checkPerm(['SD_DIV_HEAD']);
  }
  get isAd() {
    return this.checkPerm(['SD_AD_HEAD']);
  }
  get isGd() {
    return this.checkPerm(['SD_GD_HEAD']);
  }
  get isMSuper() {
    return this.checkPerm(['SD_MBOOK_ISSUE_APPROVAL']);
  }
  get isTMPSuper() {
    return this.checkPerm(['SD_TEMP_SUPERVISOR']);
  }
  get isRadioLab() {
    return this.checkPerm(['SD_RADIOLOGICAL_LAB_INCHARGE']);
  }
  get isRadioHp() {
    return this.checkPerm(['SD_RADIOLOGICAL_HP']);
  }
  get isWorkPermitHos() {
    return this.checkPerm(['SD_SEC_HEAD']);
  }
  get isRFIDcardIssue() {
    return this.checkPerm(['SD_RFIDCARD_INCHARGE']);
  }
}
