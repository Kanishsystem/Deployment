import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RfidCardComponent } from './rfid-card.component';

describe('RfidCardComponent', () => {
  let component: RfidCardComponent;
  let fixture: ComponentFixture<RfidCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RfidCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RfidCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
