import { SubFormComponent } from './../../reports/sub-form/sub-form.component';
import { Component, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CommonService } from 'src/app/api-services/common/common.service';
import { NotifyService } from 'src/app/api-services/common/notify.service';
import { SmartapiService } from 'src/app/api-services/smartapi.service';
import {
  SmartFormField,
  SmartFormNewConfig,
} from 'src/app/shared/core/SmartInterfaces/SmartFormNewInterface';
import {
  SmartTableColumnConfig,
  SmartTableConfig,
  SmartTableMainConfig,
} from 'src/app/shared/core/SmartInterfaces/SmartTableNewInterface';
import { SmartDialogService } from 'src/app/shared/core/services/smart-dialog.service';
import {
  default_delete_dialog,
  default_form_dialog,
} from '../../helpers/site-defaults';
import { get_api_route } from 'src/app/api-services/api-router';
import { SmartFileService } from 'src/app/shared/core/services/smart-file.service';

@Component({
  selector: 'app-rfid-card',
  templateUrl: './rfid-card.component.html',
})
export class RfidCardComponent {
  @ViewChild('createform') createform: any;
  @ViewChild('editform') editform: any;
  @ViewChild('viewform') viewform: any;

  @ViewChild('title_one', { static: true }) title_one!: TemplateRef<any>;
  @ViewChild('title_two', { static: true }) title_two: TemplateRef<any>;

  constructor(
    private modalService: NgbModal,
    private api: SmartapiService,
    private route: ActivatedRoute,
    private smartDialog: SmartDialogService,
    private common: CommonService,
    private notify: NotifyService,
    private smartFile: SmartFileService
  ) {}

  tableData: any;
  tableConfigNew: SmartTableConfig;
  editData: any;
  viewData: any;
  formData: any;
  status: number;
  supervisorOptions: any = [];
  mode: string = '';
  processSelection: string = '';
  selectionButton: boolean = false;
  actionTypes = [
    { value: 'wait', label: 'Waiting' },
    { value: 'process', label: 'Processed' },
    { value: 'returned/wait', label: 'Return Wait' },
    { value: 'returned/process', label: 'Return Processed' },
  ];

  get filteredActionTypes() {
    if (this.mode === 'hos' || this.mode === 'hod') {
      return this.actionTypes.filter(
        (item) => item.value === 'wait' || item.value === 'process'
      );
    }
    return this.actionTypes;
  }

  selectedId: number = 0;

  mode_data = {
    emp: {
      title: 'My RFID Card',
      url: 'SITE_RFID_CARD_GET_ALL_USER',
    },
    admin: {
      title: 'RFID Card',
      url: 'SITE_RFID_CARD_GET_ALL',
    },
    hos: {
      title: 'RFID Card-Approval',
      url: 'SITE_RFID_CARD_HOS',
    },
    hod: {
      title: 'RFID Card-Approval',
      url: 'SITE_RFID_CARD_HOD',
    },

    supervisor: {
      title: 'RFID Card ',
      url: 'SITE_RFID_CARD_SUPERVISOR_GET_ALL',
    },
  };

  get modeData() {
    return this.mode_data[this.mode] !== undefined
      ? this.mode_data[this.mode]
      : null;
  }

  get siteTitle() {
    return this.modeData?.title;
  }

  actionChange() {
    this.getTableData();
  }

  getTableData() {
    let tableUrl = get_api_route(this.modeData?.url);
    if (this.processSelection.length > 3) {
      tableUrl += '/' + this.processSelection;
    }
    this.api.smartGet(tableUrl).subscribe((res: any) => {
      this.tableData = res;
    });
  }

  ngOnInit(): void {
    this.mode = this.route.snapshot.data.mode;

    if (this.mode !== 'emp') {
      this.processSelection = 'wait';
      this.selectionButton = true;
    }
    this.getTableData();
    this.createTable();
    this.get_supervisor();
  }

  createTable() {
    let table_config: SmartTableMainConfig = {
      name: 'RFID Card',
      title: 'RFID Card Details',
      table_class: 'smart-responsive',
      download: true,
      showentries: true,
      currentpage: false,
      pagination: true,
      colsearch: true,
      search: true,
      showingentries: true,
      showEntriesClass: 'is-8',
      search_bar_placeholder: 'Search Card',
      searchBarClass: 'col-4 ',
      buttonBarClass: 'col-1 d-flex justify-content-end',
      no_results: {
        title: 'No Data Found',
        sub_title: 'Create a New RFID',
        icon: 'fa fa-user',
      },
    };

    this.tableConfigNew = {
      tableconfig: table_config,
      config: this.getTableConfig(),
      filterConfig: this.getFilterConfig(),
      filterData: {
        from_date: this.common.addDays(-30),
        to_date: this.common.currentDate(),
      },
    };
  }

  getFilterConfig() {
    let filterConfig: SmartFormField[] = [
      {
        type: 'text',
        width: 12,
        name: 'name',
        label: 'Name',
        placeHolder: 'Enter name',
      },
      {
        type: 'select',
        width: 12,
        name: 'nature_of_visitor',
        label: 'Nature of Visitor',
        placeHolder: 'Select nature of visitor',
        selectOptionType: 'self',
        selectOptions: [
          { value: 'Guest Scientist', label: 'Guest Scientist' },
          { value: 'Project Student', label: 'Project Student' },
          { value: 'Trade Apprentice', label: 'Trade Apprentice' },
          { value: 'STIPA', label: 'STIPA' },
          { value: 'JRF', label: 'JRF' },
          { value: 'Contractor', label: 'Contractor' },
        ],
      },
      {
        type: 'date',
        width: 6,
        name: 'from_date',
        label: 'From Date',
        placeHolder: 'Select from date',
        filterSettings: {
          type: 'DATE_FROM',
          field_name: 'date_of_validity',
        },
      },
      {
        type: 'date',
        width: 6,
        name: 'to_date',
        label: 'To Date',
        placeHolder: 'Select to date',
        filterSettings: {
          type: 'DATE_TO',
          field_name: 'date_of_validity',
        },
      },
      {
        type: 'text',
        width: 12,
        name: 'rfid_req_number',
        label: 'RFID Card Number',
        placeHolder: 'Enter RFID card number',
      },
    ];

    return filterConfig;
  }

  getAppTableConfig() {
    let columns = [
      ['sno', 5],
      ['rfid_number', 15],
      ['name', 15],
      ['nature_of_visitor', 15],
      ['mobile_no', 10],
      ['date_of_validity', 10],
      ['status', 10],
      ['buttonsApp', 5],
    ];
    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }

  getAdminTableConfig() {
    let columns = [
      ['sno', 3],
      ['rfid_number', 15],
      ['name', 15],
      ['nature_of_visitor', 15],
      ['mobile_no', 10],
      ['date_of_validity', 7],
      ['status', 10],
      ['buttons', 10],
    ];
    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }

  getUserTableConfig() {
    let columns = [
      ['sno', 5],
      ['rfid_number', 15],
      ['name', 15],
      ['nature_of_visitor', 15],
      ['mobile_no', 10],
      ['date_of_validity', 10],
      ['status', 10],
      ['user_buttons', 10],
    ];
    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }

  getSupervisorTableConfig() {
    let columns = [
      ['sno', 5],
      ['rfid_number', 15],
      ['name', 15],
      ['nature_of_visitor', 10],
      ['mobile_no', 10],
      ['date_of_validity', 10],
      ['status', 10],
      ['buttons', 10],
    ];
    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }
  getTableConfig() {
    if (this.mode === 'admin') {
      return this.getAdminTableConfig();
    } else if (this.mode === 'app') {
      return this.getAppTableConfig();
    } else if (
      this.mode === 'hod' ||
      this.mode === 'supervisor' ||
      this.mode === 'hos'
    ) {
      return this.getSupervisorTableConfig();
    } else {
      return this.getUserTableConfig();
    }
  }
  getTableColumns(req: any[]) {
    let tableColumns: { [key: string]: SmartTableColumnConfig } = {
      sno: {
        type: 'sno',
        title: 'S.No',
        tbody: 's_no',
      },
      rfid_number: {
        type: 'db',
        title: 'RFID Number',
        tbody: 'rfid_req_number',
      },
      name: {
        type: 'db',
        title: 'Name',
        tbody: 'name',
      },
      nature_of_visitor: {
        type: 'db',
        title: 'Nature of Visitor',
        tbody: 'nature_of_visitor',
      },
      mobile_no: {
        type: 'db',
        title: 'Mobile No',
        tbody: 'mobile_no',
      },
      date_of_validity: {
        type: 'date',
        title: 'Date of Validity',
        tbody: 'igcar_entry_date_of_validity',
        format: 'dd-MM-yyyy',
      },
      status: {
        type: 'tag',
        title: 'Status',
        tbody: 'status',
        tagCond: [
          {
            comp: '5',
            tagClass: 'is-warning',
            tagText: 'Submitted',
          },
          { comp: '10', tagClass: 'is-info', tagText: 'Hos Waiting' },
          { comp: '15', tagClass: 'is-success', tagText: 'HOD Waiting' },
          {
            comp: '20',
            tagClass: 'is-success',
            tagText: 'Supervisor waiting',
          },
          { comp: '25', tagClass: 'is-info', tagText: 'Card Issued' },
          { comp: '30', tagClass: 'is-primary', tagText: 'Card Returned' },
          { comp: '35', tagClass: 'is-danger', tagText: 'Rejected' },
        ],
      },
      buttons: {
        type: 'buttons',
        title: 'Action',
        btn_config: [
          {
            type: 'button',
            label: '',
            class: ['has-text-primary', 'is-small'],

            btn_type: 'icon',
            icon: ['fa-eye'],
            btn_func: (data) => {
              //console.log("data ", data);
              this.openViewForm(data);
            },
          },
          {
            type: 'button',
            class: ['has-text-info', 'is-small'],
            btn_type: 'icon',
            icon: ['fa-pencil-square-o'],
            btn_func: (data) => {
              // here impliments
              this.openEditForm(data);
            },
            btn_show: (data: any) => {
              //  console.log("")
            return this.processSelection !== 'returned/wait' && this.processSelection !== 'wait'? false : true;
            }, 
          },
          {
            type: 'button',
            label: '',
            class: ['has-text-info', 'is-small'],

            btn_type: 'icon',
            icon: ['fa-download'],
            btn_func: (data) => {
              this.downLoadFile(data?.ID, data?.rfid_req_number);
            },
            btn_show: (data: any) => {
              return data?.status === 30 ? true : false;
            },
          },
        ],
      },
      //   fileButton: {
      //   type: 'buttons',
      //   title: 'Document',
      //   btn_config: [
      //     {
      //       type: 'button',
      //       class: ['has-text-info'],
      //       btn_type: 'icon',
      //       icon: ['fa-download'],
      //       btn_func: (data) => {
      //         this.downLoadFile(data?.ID);
      //       },

      //     },
      //   ],
      // },
      buttonsApp: {
        type: 'buttons',
        title: 'Actions',
        btn_config: [
          {
            type: 'button',
            label: '',
            class: ['has-text-success', 'is-small'],
            btn_type: 'icon',
            icon: ['fa fa-check'],
            btn_func: (data) => {
              //console.log("data ", data);
              this.selectedId = data['ID'] !== undefined ? data['ID'] : 0;
              this.openApproveCustomDialog(
                'Do you Want to Approve the Complaint'
              );
            },
            // btn_show:()=>{
            //   return this.processSelection=="wait" ? true : false;
            // }
          },
          {
            type: 'button',
            label: '',
            class: ['has-text-danger', 'is-small'],
            btn_type: 'icon',
            icon: ['fa fa-times'],
            btn_func: (data) => {
              //console.log("data ", data);
              this.selectedId = data['ID'] !== undefined ? data['ID'] : 0;
              this.openApproveCustomDialog(
                'Do you Want to Reject the Complaint'
              );
            },
            btn_show: () => {
              return this.processSelection == 'wait' ? true : false;
            },
          },
        ],
      },
      user_buttons: {
        type: 'buttons',
        title: 'Actions',
        btn_config: [
          {
            type: 'button',
            label: '',
            class: ['has-text-primary', 'is-small'],

            btn_type: 'icon',
            icon: ['fa-eye'],
            btn_func: (data) => {
              //console.log("data ", data);
              this.openViewForm(data);
            },
          },
          {
            type: 'button',
            label: '',
            class: ['has-text-info', 'is-small'],
            btn_type: 'icon',
            icon: [' fa fa-pencil-square-o'],
            btn_func: (data) => {
              this.openEditUserForm(data);
            },
            btn_show: (data: any) => {
              //  console.log("")
              return data?.status === 10 ? true : false;
            },
          },
          {
            type: 'button',
            label: '',
            class: ['has-text-info', 'is-small'],

            btn_type: 'icon',
            icon: ['fa-download'],
            btn_func: (data) => {
              this.downLoadFile(data?.ID, data?.rfid_req_number);
            },
            btn_show: (data: any) => {
              return data?.status === 30 ? true : false;
            },
          },
          {
            type: 'button',
            label: '',
            class: ['has-text-danger', 'is-small'],
            btn_type: 'icon',
            icon: ['fa fa-trash'],
            btn_func: (data) => {
              //console.log("data ", data);
              this.selectedId = data['ID'] !== undefined ? data['ID'] : 0;
              this.openDeleteCustomDialog();
            },
            btn_show: (data: any) => {
              //  console.log("")
              return data?.status === 10 ? true : false;
            },
          },
        ],
      },
    };

    let output_columns: SmartTableColumnConfig[] = [];
    req.forEach((element) => {
      let column: SmartTableColumnConfig = tableColumns[element[0]];
      if (column && element[1] !== undefined) {
        column['width'] = element[1] + '%';
        output_columns.push(column);
      }
    });
    return output_columns;
  }

  createFormConfig() {
    let form_fields: SmartFormField[] = [
      {
        type: 'template',
        name: 'person_details_header',
        label: 'Personnel Details',
        width: 12,
        template: this.title_one,
      },
      {
        type: 'date',
        width: 4,
        label: 'From',
        name: 'from_date',
        rightIcon: 'fa-calendar',
        placeHolder: 'Select from date',
        filterSettings: {
          type: 'DATE_FROM',
          field_name: 'created_time',
        },
      },
      {
        type: 'date',
        width: 4,
        label: 'To',
        name: 'to_date',
        rightIcon: 'fa-calendar',
        placeHolder: 'Select to date',
        filterSettings: {
          type: 'DATE_TO',
          field_name: 'created_time',
        },
      },
      {
        type: 'select',
        name: 'nature_of_visitor',
        label: 'Nature of Visitor',
        width: 4,
        selectOptionType: 'self',
        selectOptions: [
          { value: 'Guest Scientist', label: 'Guest Scientist' },
          { value: 'Project Student', label: 'Project Student' },
          { value: 'Trade Apprentice', label: 'Trade Apprentice' },
          { value: 'STIPAC', label: 'STIPAC' },
          { value: 'JRF', label: 'JRF' },
        ],
        placeHolder: 'Select Nature of Visitor',
      },
      {
        type: 'template',
        name: 'person_details_header',
        label: 'Personnel Details',
        width: 12,
        template: this.title_two,
      },
      {
        type: 'text',
        width: 3,
        name: 'igcar_entry_permit_no',
        label: 'IGCAR Entry Permit No.',
        placeHolder: 'Enter permit number',
      },
      {
        type: 'date',
        width: 3,
        label: 'Date of Validity',
        name: 'igcar_entry_date_of_validity',
        rightIcon: 'fa-calendar',
        placeHolder: 'Select validity date',
      },
      {
        type: 'text',
        width: 6,
        name: 'name',
        label: 'Name',
        placeHolder: 'Enter full name',
      },
      {
        type: 'text',
        width: 3,
        name: 'age',
        label: 'Age',
        placeHolder: 'Enter age',
      },
      {
        type: 'select',
        name: 'gender',
        label: 'Gender ',
        width: 3,
        selectOptionType: 'self',
        selectOptions: [
          { value: 'Male', label: 'Male' },
          { value: 'Female', label: 'Female' },
        ],
        placeHolder: 'Select gender',
      },
      {
        type: 'text',
        width: 3,
        name: 'mobile_no',
        label: 'Mobile No.',
        placeHolder: 'Enter mobile number',
      },
      {
        type: 'text',
        width: 3,
        name: 'intercom_no',
        label: 'Contact Number (Intercom)',
        placeHolder: 'Enter intercom number',
      },
      {
        type: 'textarea',
        width: 6,
        name: 'institute_address',
        label: 'Institute Address',
        placeHolder: 'Enter institute address',
      },
      {
        type: 'textarea',
        width: 6,
        name: 'area_of_visit',
        label: 'Area of Visit / work (LAB No)',
        placeHolder: 'Enter lab number',
      },

      // {
      //   type: 'select',
      //   width: 6,
      //   label: 'Approver',
      //   name: 'hos_id',
      //   selectOptionType: 'self',
      //   selectOptions: this.supervisorOptions,
      // },
      // {
      //   type: 'select',
      //   width: 6,
      //   label: 'Forwarding Authority',
      //   name: 'forwarding_auth',
      //   selectOptionType: 'self',
      //   selectOptions: this.supervisorOptions,
      //   // hideFunction: () => this.mode !== 'supervisor',
      // },
      {
        type: 'button',
        label: 'Submit',
        name: 'submit',
        width: 12,
        buttonClass: 'smart-action-button is-fullwidth',
        buttonType: 'button',
        buttonSubmitType: 'submit',
        leftIcon: 'fa-check',
        buttonFunction: (data: any) => {
          console.log('Form data submitted', data);
          this.submitData(data);
        },
        hideFunction: (item: any, getValue: any) => {
          let id = getValue('ID') !== undefined ? parseInt(getValue('ID')) : 0;
          return id < 1 ? false : true;
        },
      },
      {
        type: 'button',
        label: 'Update',
        name: 'Submit',
        width: 12,
        buttonClass: 'smart-action-button is-fullwidth',
        buttonType: 'button',
        buttonSubmitType: 'submit',
        leftIcon: 'fa-check',
        buttonFunction: (data: any) => {
          this.updateDate(data);
        },
        hideFunction: (item: any, getValue: any) => {
          let id = getValue('ID') !== undefined ? parseInt(getValue('ID')) : 0;
          return id < 1 ? true : false;
        },
      },
    ];

    let formconfig: SmartFormNewConfig = {
      name: 'Visitor Registration Form',
      SmartFields: form_fields,
    };
    return formconfig;
  }

  editFormConfig() {
    let form_fileds: SmartFormField[] = [
      {
        type: 'select',
        width: 12,
        name: 'status',
        label: 'Status',
        placeHolder: 'Select status',
        selectOptionType: 'self',
        selectOptions: (() => {
          if (this.mode === 'supervisor') {
            if (this.editData?.status === 20) {
              return [
                { value: 'approve', label: 'Card Issue' },
                { value: 'reject', label: 'Rejected' },
              ];
            } else if (this.editData?.status === 25) {
              return [
                { value: 'approve', label: 'Card  Return' },
                { value: 'reject', label: 'Rejected' },
              ];
            }
          }

          return [
            { value: 'approve', label: 'Approved' },
            { value: 'reject', label: 'Rejected' },
          ];
        })(),

        validations: [{ type: 'required', msg: 'Required' }],
        // hideFunction: () => this.mode !== 'hod',
      },
      {
        type: 'text',
        width: 6,
        name: 'card_no',
        label: 'Card No.',
        placeHolder: 'Enter Card No',
        hideFunction: () => this.mode !== 'supervisor',
      },
      // {
      //   type: 'select',
      //   width: 6,
      //   label: 'Forwarding Authority',
      //   name: 'forwarding_auth',
      //   selectOptionType: 'self',
      //   selectOptions: this.supervisorOptions,
      //   hideFunction: () => this.mode !== 'supervisor',
      // },
      {
        type: 'date',
        width: 6,
        label: 'Return Date',
        name: 'card_date',
        rightIcon: 'fa-calendar',
        placeHolder: 'Select Card Date',
        hideFunction: () => {
          // Access status directly from component's editData
          const shouldShow =
            this.mode === 'supervisor' && this.editData?.status == 25;
          return !shouldShow;
        },
      },
      {
        type: 'textarea',
        width: 12,
        name: 'remarks',
        label: 'Remarks',
        placeHolder: 'Enter remarks if any',
        hideFunction: () => this.mode !== 'hos' && this.mode !== 'hod',
      },
      {
        type: 'textarea',
        width: 12,
        name: 'supervisor_remarks',
        label: 'Remarks',
        placeHolder: 'Enter remarks if any',
        hideFunction: () => this.mode !== 'supervisor',
      },

      {
        type: 'button',
        label: 'Update',
        name: 'submit',
        width: 12,
        buttonClass: 'smart-action-button is-fullwidth',
        buttonType: 'button',
        buttonSubmitType: 'submit',
        leftIcon: 'fa-check',
        buttonFunction: (data) => {
          console.log('data', data);
          if (this.editData?.status === 25) {
            this.updateDate_card(data);
          } else {
            this.updateDate(data);
          }
        },
      },
    ];

    return {
      name: 'Edit RFID Card',
      SmartFields: form_fileds,
    };
  }
  // Dialog methods
  openForm(data: any = null) {
    this.formData = data || {};
    const options = {
      title: 'RFID Card Form',
      template: this.createform,
      width: 90,
    };
    // this.smartDialog.openDialog(default_form_dialog(options));
    let dialog_options = default_form_dialog(options);
    dialog_options.width = 90;
    this.smartDialog.openDialog(dialog_options);
  }

  openViewForm(data: any) {
    const id = data.ID || 0;
    this.api
      .smartPost(get_api_route('SITE_RFID_CARD_ONE'), { id })
      .subscribe((res) => {
        this.viewData = res;
        const options = {
          title: 'RFID Card Details',
          template: this.viewform,
          width: 70,
        };
        let dialog_options = default_form_dialog(options);
        dialog_options.width = 90;
        this.smartDialog.openDialog(dialog_options);
      });
  }

  openEditForm(data: any) {
    const id = data.ID || 0;
    this.api
      .smartPost(get_api_route('SITE_RFID_CARD_ONE'), { id })
      .subscribe((res) => {
        this.editData = res;

        const options = {
          title: 'Edit RFID Card',
          template: this.editform,
          width: 90,
          formData: this.editData,
        };
        let dialog_options = default_form_dialog(options);
        dialog_options.width = 70;
        this.smartDialog.openDialog(dialog_options);
      });
  }
  openEditUserForm(data) {
    let id = data.ID !== undefined ? data.ID : 0;
    let get_one = get_api_route('SITE_RFID_CARD_ONE');
    this.api.smartPost(get_one, { id: id }).subscribe((res: any) => {
      // this.formData = res;
      this.openForm(res);
    });
  }
  // Data operations
  submitData(data: any) {
    this.api.smartPost('SITE_RFID_CARD_INSERT', data).subscribe(() => {
      this.notify.success('RFID Card created successfully');
      this.smartDialog.closeDialog();
      this.getTableData();
    });
  }
  updateDate_card(data: any) {
    const id = data.ID || 0;
    data.id = id;

    let updateUrl = get_api_route('SITE_RFID_CARD_RETURN_UPDATE');

    this.api.smartPost(updateUrl, data).subscribe((res: any) => {
      this.notify.success('Updated successfully');
      this.smartDialog.closeDialog();
      this.getTableData();
    });
  }
  updateDate(data: any) {
    const id = data.ID || 0;
    data.id = id;
    // console.log('data status', this.tableData?.status);
    let updateUrl = '';

    if (this.mode === 'supervisor') {
      updateUrl = 'SITE_RFID_CARD_SUP_UPADTE';
    } else if (this.mode === 'emp') {
      updateUrl = 'SITE_RFID_CARD_USER_UPDATE';
    } else if (this.mode === 'hos') {
      updateUrl = 'SITE_RFID_CARD_HOS_UPDATE';
    } else if (this.mode === 'hod') {
      updateUrl = 'SITE_RFID_CARD_HOD_UPDATE';
    } else {
      updateUrl = 'SITE_RFID_CARD_UPDATE';
    }

    // console.log('Using URL:', updateUrl);

    this.api.smartPost(get_api_route(updateUrl), data).subscribe(() => {
      this.notify.success('RFID Card updated successfully');
      this.smartDialog.closeDialog();
      this.getTableData();
    });
  }

  delete_one() {
    let deleteUrl = get_api_route('SITE_RFID_CARD_DELETE_ONE');
    this.api.smartPost(deleteUrl, { id: this.selectedId }).subscribe((data) => {
      this.notify.success('Deleted successfully');
      this.getTableData();
    });
  }
  openApproveCustomDialog(msg) {
    let dialog_options = default_delete_dialog(msg);
    this.smartDialog.openDialog(dialog_options).confirmed.subscribe((data) => {
      if (data.action == 'yes') {
        this.app_status_update_one('approve');
      }
    });
  }
  app_status_update_one(status: string) {
    // url needs to be changed
    let deleteUrl = get_api_route('SITE_RFID_CARD_DELETE_ONE');
    this.api
      .smartPost(deleteUrl, { id: this.selectedId, action: status })
      .subscribe((data) => {
        this.notify.success('Deleted successfully');
        this.getTableData();
      });
  }

  openDeleteCustomDialog() {
    let dialog_options = default_delete_dialog(
      'Do you want to Delete?',
      'The Action Cannot Be Reverted'
    );
    this.smartDialog.openDialog(dialog_options).confirmed.subscribe((data) => {
      if (data.action == 'yes') {
        this.delete_one();
      }
    });
  }

  get_supervisor() {
    this.api
      .smartGet(get_api_route('SITE_RFID_CARD_GET_ALL_SELECT'))
      .subscribe((res) => {
        this.supervisorOptions = res;
      });
  }

  statusMap = [
    {
      comp: '5',
      tagClass: 'is-warning',
      tagText: 'Submitted',
    },
    { comp: '10', tagClass: 'is-info', tagText: 'Hos Waiting' },
    { comp: '15', tagClass: 'is-success', tagText: 'HOD Waiting' },
    {
      comp: '20',
      tagClass: 'is-success',
      tagText: 'Supervisor waiting',
    },
    { comp: '25', tagClass: 'is-info', tagText: 'Card Issued' },
    { comp: '30', tagClass: 'is-primary', tagText: 'Card Returned' },
    { comp: '35', tagClass: 'is-danger', tagText: 'Rejected' },
  ];

  get_status_disp(status: any): string {
    const found = this.statusMap.find((s) => s.comp === String(status));
    return found ? found.tagText : 'Unknown';
  }

  get_status_class(status: any): string {
    const found = this.statusMap.find((s) => s.comp === String(status));
    return found ? found.tagClass : '';
  }
  downLoadFile(id, fileName: string) {
    let payload = { id: id };
    const finalFileName = `${fileName}.pdf`;
    this.api
      .smartPost('SITE_RFID_CARD_PDF_DOWLOAD', payload)
      .subscribe((res: any) => {
        this.smartFile.downLoadFile(res?.content, finalFileName);
      });
  }
  //    downLoadFile(id){
  //   let payload = {id:id};
  //   const finalFileName = `RFID.pdf`;
  //   this.api.smartPost("SITE_RFID_CARD_PDF_DOWLOAD",payload).subscribe((res:any)=>{
  //     this.smartFile.downLoadFile(res?.content, finalFileName );
  //  })

  // }
}
