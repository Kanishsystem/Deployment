import { Component, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CommonService } from 'src/app/api-services/common/common.service';
import { NotifyService } from 'src/app/api-services/common/notify.service';
import { SmartapiService } from 'src/app/api-services/smartapi.service';

import {
  SmartTableColumnConfig,
  SmartTableConfig,
  SmartTableMainConfig,
} from 'src/app/shared/core/SmartInterfaces/SmartTableNewInterface';
import { SmartDialogService } from 'src/app/shared/core/services/smart-dialog.service';

import { get_api_route } from 'src/app/api-services/api-router';
import { SmartFileService } from 'src/app/shared/core/services/smart-file.service';

@Component({
  selector: 'app-rfid-expiry',
  templateUrl: './rfid-expiry.component.html',
})
export class RfidExpiryComponent {
  constructor(
    private modalService: NgbModal,
    private api: SmartapiService,
    private route: ActivatedRoute,
    private smartDialog: SmartDialogService,
    private common: CommonService,
    private notify: NotifyService,
    private smartFile: SmartFileService
  ) {}

  tableData: any;
  tableConfigNew: SmartTableConfig;
  editData: any;
  viewData: any;
  formData: any;
  mode: string = '';
  processSelection: string = '';
  selectionButton: boolean = false;
  selectedId: number = 0;

  mode_data = {
    emp: {
      title: 'RFID Card Expiry',
      url: 'SITE_RFID_RETURN_GET_ALL',
    },
  };

  get modeData() {
    return this.mode_data[this.mode] !== undefined
      ? this.mode_data[this.mode]
      : null;
  }

  get siteTitle() {
    return this.modeData?.title;
  }

  actionChange() {
    this.getTableData();
    this.createTable();
  }

  getTableData() {
    let tableUrl = get_api_route(this.modeData?.url);
    if (this.processSelection.length > 3) {
      tableUrl += '/' + this.processSelection;
    }
    this.api.smartGet(tableUrl).subscribe((res: any) => {
      this.tableData = res;
    });
  }

  ngOnInit(): void {
    this.mode = this.route.snapshot.data.mode;

    if (this.mode !== 'emp' && this.mode !== 'supervisor') {
      this.processSelection = 'wait';
      this.selectionButton = true;
    }

    this.getTableData();
    this.createTable();
  }

  getTableConfig() {
    return this.getUserTableConfig();
  }

  createTable() {
    let table_config: SmartTableMainConfig = {
      name: 'Radiology',
      title: 'Vendors Details',
      table_class: 'smart-responsive',
      download: true,
      showentries: true,
      currentpage: false,
      pagination: true,
      colsearch: true,
      search: true,
      showingentries: true,
      showEntriesClass: 'is-8',
      search_bar_placeholder: 'Search...',
      searchBarClass: 'col-4',
      buttonBarClass: 'col-1 d-flex justify-content-end',
      no_results: {
        title: 'No Radiology Found',
        sub_title: 'Create a New Radiology',
        icon: 'fa fa-user',
      },
    };

    this.tableConfigNew = {
      tableconfig: table_config,
      config: this.getTableConfig(),
      filterData: {
        from_date: this.common.addDays(-30),
        to_date: this.common.currentDate(),
      },
    };
  }

  getUserTableConfig() {
    let columns = [
      ['sno', 5],

      ['rfid_req_number', 15],
      ['name', 15],
      ['igcar_entry_permit_no', 10],
      ['nature_of_visitor', 15],
      ['igcar_entry_date_of_validity', 10],
      ['mobile_no', 10],
      ['intercom_no', 10],
      ['created_by', 10],
      // ['status', 10],
    ];
    return this.getTableColumns(columns);
  }

  getTableColumns(req): SmartTableColumnConfig[] {
    const tableColumns: { [key: string]: SmartTableColumnConfig } = {
      sno: {
        type: 'sno',
        title: 'S.No',
        tbody: 's_no',
      },
      name: {
        type: 'db',
        title: 'Name',
        tbody: 'name',
      },
      nature_of_visitor: {
        type: 'db',
        title: 'Nature of Visitor',
        tbody: 'nature_of_visitor',
      },
      igcar_entry_permit_no: {
        type: 'db',
        title: 'Permit No',
        tbody: 'igcar_entry_permit_no',
      },
      igcar_entry_date_of_validity: {
        type: 'date',
        title: 'Validity Date',
        tbody: 'igcar_entry_date_of_validity',
        customFormat: true,
        format: 'dd-MM-YYYY',
      },
      mobile_no: {
        type: 'db',
        title: 'Mobile No',
        tbody: 'mobile_no',
      },
      intercom_no: {
        type: 'db',
        title: 'Intercom No',
        tbody: 'intercom_no',
      },
      rfid_req_number: {
        type: 'db',
        title: 'RFID Request No',
        tbody: 'rfid_req_number',
      },
      created_by: {
        type: 'db',
        title: 'Created By',
        tbody: 'created_by',
      },
      status: {
        type: 'tag',
        title: 'Status',
        tbody: 'status',
        tagCond: [
          {
            comp: '10',
            tagClass: 'is-link is-dark',
            tagText: 'Submitted...Waiting for lab in charge',
          },
          {
            comp: '15',
            tagClass: 'is-link is-dark',
            tagText: 'Waiting for hp',
          },
          {
            comp: '20',
            tagClass: 'is-success',
            tagText: 'Approved By hp',
          },
          {
            comp: '14',
            tagClass: 'is-danger',
            tagText: 'Rejected By lab in charge',
          },
          {
            comp: '19',
            tagClass: 'is-danger',
            tagText: 'Rejected By hp',
          },
        ],
      },
    };

    const outputColumns: SmartTableColumnConfig[] = [];
    req.forEach((element) => {
      const column = tableColumns[element[0]];
      if (column) {
        if (element[1] !== undefined) {
          column['width'] = element[1] + '%';
        }
        outputColumns.push(column);
      }
    });

    return outputColumns;
  }
}
