import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RfidExpiryComponent } from './rfid-expiry.component';

describe('RfidExpiryComponent', () => {
  let component: RfidExpiryComponent;
  let fixture: ComponentFixture<RfidExpiryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RfidExpiryComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RfidExpiryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
