import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TemporaryAdvanceComponent } from './temporary-advance.component';

describe('TemporaryAdvanceComponent', () => {
  let component: TemporaryAdvanceComponent;
  let fixture: ComponentFixture<TemporaryAdvanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TemporaryAdvanceComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TemporaryAdvanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
