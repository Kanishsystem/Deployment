import { Component, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { get_api_route } from 'src/app/api-services/api-router';
import { SmartapiService } from 'src/app/api-services/smartapi.service';
import {
  SmartFormField,
  SmartFormNewConfig,
} from 'src/app/shared/core/SmartInterfaces/SmartFormNewInterface';
import {
  SmartTableColumnConfig,
  SmartTableConfig,
  SmartTableMainConfig,
} from 'src/app/shared/core/SmartInterfaces/SmartTableNewInterface';
import {
  default_delete_dialog,
  default_form_dialog,
} from '../../helpers/site-defaults';
import { SmartDialogService } from 'src/app/shared/core/services/smart-dialog.service';
import { CommonService } from 'src/app/api-services/common/common.service';
import { NotifyService } from 'src/app/api-services/common/notify.service';

@Component({
  selector: 'app-temporary-advance',
  templateUrl: './temporary-advance.component.html',
})
export class TemporaryAdvanceComponent {
  @ViewChild('createform') createform: any;
  @ViewChild('editform') editform: any;
  @ViewChild('viewform') viewform: any;

  constructor(
    private route: ActivatedRoute,
    private api: SmartapiService,
    private smartDialog: SmartDialogService,
    private common: CommonService,
    private notify: NotifyService
  ) {}

  tableData: any;
  tableConfigNew: SmartTableConfig;
  editData: any;
  viewData: any;
  formData: any;
  mode: string = '';
  processSelection: string = '';
  selectionButton: boolean = false;
  filterAmountStart: number | null = null;
  filterAmountEnd: number | null = null;
  
  actionTypes = [
    { value: 'wait', label: 'Waiting' },
    { value: 'process', label: 'Processed' },
  ];
  
  selectedId: number = 0;
  mode_data = {
    emp: {
      title: 'Temporary Advance Settlement',
      url: 'SITE_TEMPORARY_ADVANCE_GET_ALL_USER',
    },
    app: {
      title: 'Temporary Advance-Supervisor',
      url: 'SITE_TEMPORARY_ADVANCE_SUPERVISOR',
    },
    admin: {
      title: 'Temporary Advance',
      url: 'SITE_TEMPORARY_ADVANCE_GET_ALL',
    },
    supervisor: {
      title: 'Temporary Advance-Supervisor',
      url: 'SITE_TEMPORARY_ADVANCE_SUPERVISOR',
    },
    hos: {
      title: 'Temporary Advance - HOS',
      url: 'SITE_TEMPORARY_ADVANCE_HOS',
    },
    hod: {
      title: 'Temporary Advance - HOD',
      url: 'SITE_TEMPORARY_ADVANCE_HOD',
    },
    ad: {
      title: 'Temporary Advance - AD',
      url: 'SITE_TEMPORARY_ADVANCE_AD',
    },
    gd: {
      title: 'Temporary Advance - GD',
      url: 'SITE_TEMPORARY_ADVANCE_GD',
    },
  };

  get modeData() {
    return this.mode_data[this.mode] !== undefined
      ? this.mode_data[this.mode]
      : null;
  }

  get siteTitle() {
    return this.modeData?.title;
  }

  actionChange() {
    this.getTableData();
    this.createTable();
  }

  getTableData() {
  let tableUrl = get_api_route(this.modeData?.url);
  if (this.processSelection.length > 3) {
    tableUrl += '/' + this.processSelection;
  }

  const filterParams: any = {};

  if (this.filterAmountStart !== null) {
    filterParams.amount_start = this.filterAmountStart;
  }
  if (this.filterAmountEnd !== null) {
    filterParams.amount_end = this.filterAmountEnd;
  }

  this.api.smartGet(tableUrl, filterParams).subscribe((res: any) => {
    this.tableData = res;
  });
}


 

  ngOnInit(): void {
    this.mode = this.route.snapshot.data.mode;

    if (this.mode !== 'emp' && this.mode !== 'supervisor') {
      this.processSelection = this.processSelection || 'wait';
      this.selectionButton = true;
    }
    
    this.getTableData();
    this.createTable();
  }

  getTableConfig() {
    if (
      this.mode === 'admin' ||
      this.mode === 'hod' ||
      this.mode === 'hos' ||
      this.mode === 'ad' ||
      this.mode === 'gd'
    ) {
      return this.getAdminTableConfig();
    } else if (this.mode === 'app') {
      return this.getAppTableConfig();
    } else if (this.mode === 'supervisor') {
      return this.getSupervisorTableConfig();
    } else {
      return this.getUserTableConfig();
    }
  }
getFilterConfig() {
  let filterConfig: SmartFormField[] = [
    {
      type: 'text',
      width: 12,
      name: 'amount_start',
      label: 'Amount From',
      placeHolder: 'Minimum Amount',
      onChange: (value: any) => {
        this.filterAmountStart = value ? parseFloat(value) : null;
        this.getTableData(); 
      },
    },
    {
      type: 'text',
      width: 12,
      name: 'amount_end',
      label: 'Amount To',
      placeHolder: 'Maximum Amount',
      onChange: (value: any) => {
        this.filterAmountEnd = value ? parseFloat(value) : null;
        this.getTableData();
      },
    },
  ];
  return filterConfig;
}


  getTableColumns(req) {
    let tableColumns: { [key: string]: SmartTableColumnConfig } = {
      sno: {
        type: 'sno',
        title: 'S.No',
        tbody: 's_no',
      },
      requester_name: {
        type: 'db',
        title: 'Requester Name',
        tbody: 'created_by',
      },
      temporary_advance_number: {
        type: 'db',
        title: 'Advance No.',
        tbody: 'temporary_advance_number',
      },
      title: {
        type: 'db',
        title: 'Title',
        tbody: 'title',
      },
      advance_amount: {
        type: 'db',
        title: 'Advance Amount',
        tbody: 'advance_amount',
      },
      stock_reg_no: {
        type: 'db',
        title: 'Stock Reg No.',
        tbody: 'stock_reg_no',
      },
      balance: {
        type: 'db',
        title: 'Balance',
        tbody: 'balance',
      },
      description: {
        type: 'db',
        title: 'Description',
        tbody: 'description',
      },
      requester: {
        type: 'date',
        title: 'Date',
        tbody: 'created_time',
        customFormat: true,
        format: 'dd-MM-YYYY',
      },
      status: {
        type: 'tag',
        title: 'Status',
        tbody: 'status',
        tagCond: [
          {
            comp: '5',
            tagClass: 'is-link is-dark',
            tagText: 'Submitted... Waiting for Supervisor',
          },
          {
            comp: '10',
            tagClass: 'is-link is-dark',
            tagText: 'Submitted... Waiting for HOS',
          },
          {
            comp: '15',
            tagClass: 'is-link is-dark',
            tagText: 'Waiting for HOD',
          },
          {
            comp: '20',
            tagClass: 'is-info',
            tagText: 'Waiting for AD',
          },
          {
            comp: '25',
            tagClass: 'is-link is-dark',
            tagText: 'Waiting for GD',
          },
          {
            comp: '14',
            tagClass: 'is-danger',
            tagText: 'Rejected by HOS',
          },
          {
            comp: '19',
            tagClass: 'is-danger',
            tagText: 'Rejected by HOD',
          },
          {
            comp: '24',
            tagClass: 'is-danger',
            tagText: 'Rejected by AD',
          },
          {
            comp: '29',
            tagClass: 'is-danger',
            tagText: 'Rejected by GD',
          },
          {
            comp: '30',
            tagClass: 'is-success',
            tagText: 'Approved by GD',
          },
          {
            comp: '35',
            tagClass: 'is-success',
            tagText: 'Approved',
          },
        ],
      },
      buttons: {
        type: 'buttons',
        title: 'Action',
        btn_config: [
          {
            type: 'button',
            class: ['has-text-info', 'is-small'],
            btn_type: 'icon',
            icon: ['fa-pencil-square-o'],
            btn_func: (data) => {
              this.openEditForm(data);
            },
          },
        ],
      },
      buttonsApp: {
        type: 'buttons',
        title: 'Actions',
        btn_config: [
          {
            type: 'button',
            label: '',
            class: ['has-text-primary', 'is-small'],
            btn_type: 'icon',
            icon: ['fa-eye'],
            btn_func: (data) => {
              this.openViewForm(data);
            },
          },
          {
            type: 'button',
            label: '',
            class: ['has-text-success', 'is-small'],
            btn_type: 'icon',
            icon: ['fa-check'],
            btn_func: (data) => {
              this.selectedId = data['ID'] !== undefined ? data['ID'] : 0;
              this.openApproveCustomDialog(
                'Do you Want to Approve the Temporary Advance',
                'approve'
              );
            },
            btn_show: () => {
              return this.processSelection == 'wait' ? true : false;
            },
          },
          {
            type: 'button',
            label: '',
            class: ['has-text-danger', 'is-small'],
            btn_type: 'icon',
            icon: ['fa-times'],
            btn_func: (data) => {
              this.selectedId = data['ID'] !== undefined ? data['ID'] : 0;
              this.openApproveCustomDialog(
                'Do you Want to Reject the Temporary Advance',
                'reject'
              );
            },
            btn_show: () => {
              return this.processSelection == 'wait' ? true : false;
            },
          },
        ],
      },
      user_buttons: {
        type: 'buttons',
        title: 'Actions',
        btn_config: [
          {
            type: 'button',
            label: '',
            class: ['has-text-primary', 'is-small'],
            btn_type: 'icon',
            icon: ['fa-eye'],
            btn_func: (data) => {
              this.openViewForm(data);
            },
          },
          {
            type: 'button',
            label: '',
            class: ['has-text-danger', 'is-small'],
            btn_type: 'icon',
            icon: ['fa fa-trash'],
            btn_func: (data) => {
              this.selectedId = data['ID'] !== undefined ? data['ID'] : 0;
              this.openDeleteCustomDialog();
            },
            btn_show: (data) => {
              return data?.status === 5 ? true : false;
            },
          },
        ],
      },
    };

    let output_columns: SmartTableColumnConfig[] = [];
    req.forEach((element) => {
      let column: SmartTableColumnConfig =
        tableColumns[element[0]] !== undefined
          ? tableColumns[element[0]]
          : null;
      if (column !== null && element[1] !== undefined) {
        column['width'] = element[1] + '%';
      }
      if (column != null) {
        output_columns.push(column);
      }
    });
    return output_columns;
  }

  getAppTableConfig() {
    let columns = [
      ['sno', 5],
      ['temporary_advance_number', 12],
      ['requester_name', 15],
      ['title', 10],
      ['advance_amount', 10],
      ['balance', 10],
      ['stock_reg_no', 10],
      ['status', 10],
      ['buttonsApp', 10],
    ];
    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }

  getAdminTableConfig() {
    let columns = [
      ['sno', 5],
      ['temporary_advance_number', 12],
      ['title', 10],
      ['requester_name', 15],
      ['requester', 10],
      ['advance_amount', 10],
      ['balance', 10],
      ['stock_reg_no', 10],
      ['status', 10],
    ];
    if (this.processSelection === 'wait' && this.mode !== 'admin') {
      columns.push(['buttons', 10]);
    }

    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }

  getSupervisorTableConfig() {
    let columns = [
      ['sno', 5],
      ['temporary_advance_number', 12],
      ['title', 10],
      ['requester_name', 15],
      ['requester', 10],
      ['advance_amount', 10],
      ['balance', 10],
      ['stock_reg_no', 10],
      ['status', 10],
      ['buttons', 10],
    ];
    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }

  getUserTableConfig() {
    let columns = [
      ['sno', 5],
      ['temporary_advance_number', 15],
      ['title', 10],
      ['advance_amount', 10],
      ['balance', 10],
      ['stock_reg_no', 10],
      ['description', 20],
      ['status', 10],
      ['fileButton', 5],
      ['user_buttons', 10],
    ];
    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }

  createTable() {
    let table_config: SmartTableMainConfig = {
      name: 'Temporary Advance ',
      title: '',
      table_class: 'smart-responsive',
      download: true,
      showentries: true,
      currentpage: false,
      pagination: true,
      colsearch: true,
      search: true,
      showEntriesClass: 'is-8',
      search_bar_placeholder: 'Search Temporary Advance',
      searchBarClass: 'col-4 ',
      buttonBarClass: 'col-1 d-flex justify-content-end',
      no_results: {
        title: 'No Settlements Found',
        sub_title: 'Create a New Settlements',
        icon: 'fa fa-user',
      },
    };

    this.tableConfigNew = {
      tableconfig: table_config,
      config: this.getTableConfig(),
      filterConfig: this.getFilterConfig(),
    };
  }

  // ... [rest of the methods remain the same as in your original code]
  // Only the filter-related methods and properties have been added/modified

  createFormConfig() {
    let form_fileds: SmartFormField[] = [
      {
        type: 'text',
        name: 'title',
        width: 12,
        label: 'Title',
        placeHolder: 'Title',
        validations: [
          {
            type: 'required',
            msg: 'Title is Required',
          },
        ],
      },
      {
        type: 'text',
        name: 'advance_amount',
        width: 12,
        label: 'Advance Amount',
        placeHolder: 'Advance Amount',
        validations: [
          {
            type: 'required',
            msg: 'Advance Amount is Required',
          },
        ],
      },
      {
        type: 'text',
        name: 'purchase_amount',
        width: 12,
        label: 'Purchase Amount',
        placeHolder: 'Purchase Amount',
        validations: [
          {
            type: 'required',
            msg: 'Purchase Amount is Required',
          },
        ],
        onChange: (get_value, set_value) => {
          const advance_amount = parseFloat(get_value('advance_amount')) || 0;
          const purchase_amount = parseFloat(get_value('purchase_amount')) || 0;
          const balance_amount = advance_amount - purchase_amount;
          set_value('balance', balance_amount);
        }
      },
      {
        type: 'text',
        name: 'balance',
        width: 12,
        label: 'Balance',
        placeHolder: 'Balance',
        disabled_func: true,
        validations: [
          {
            type: 'required',
            msg: 'Balance is Required',
          },
        ],
      },
      {
        type: 'text',
        name: 'stock_reg_no',
        width: 12,
        label: 'Stock Reg No',
        placeHolder: 'Stock Reg No',
        validations: [
          {
            type: 'required',
            msg: 'Stock Reg No is Required',
          },
        ],
      },
      {
        type: 'textarea',
        name: 'description',
        width: 12,
        label: 'Description',
        placeHolder: 'Description',
        validations: [
          {
            type: 'required',
            msg: 'Description is Required',
          },
        ],
      },
      {
        type: 'button',
        label: 'Submit',
        name: 'Submit',
        width: 12,
        buttonClass: 'smart-action-button is-fullwidth',
        buttonType: 'button',
        buttonSubmitType: 'submit',
        leftIcon: 'fa-check',
        buttonFunction: (data: any) => {
          this.submitData(data);
        },
        hideFunction: (item: any, getValue: any) => {
          let id = getValue('ID') !== undefined ? parseInt(getValue('ID')) : 0;
          return id > 0 ? true : false;
        },
      },
      {
        type: 'button',
        label: 'Update ',
        name: 'Submit',
        width: 12,
        buttonClass: 'smart-action-button is-fullwidth',
        buttonType: 'button',
        buttonSubmitType: 'submit',
        leftIcon: 'fa-check',
        buttonFunction: (data: any) => {
          this.updateDate(data);
        },
        hideFunction: (item: any, getValue: any) => {
          let id = getValue('ID') !== undefined ? parseInt(getValue('ID')) : 0;
          return id < 1 ? true : false;
        },
      },
    ];

    let formconfig: SmartFormNewConfig = {
      name: 'Book List form',
      SmartFields: form_fileds,
    };
    return formconfig;
  }

  update_status = [
    { value: 'approve', label: 'Approved' },
    { value: 'reject', label: 'Rejected' },
  ];
  update_SuperStatus = [
    { value: 10, label: 'Approved' },
    { value: 4, label: 'Rejected' },
  ];

  editFormConfig() {
    let form_fileds: SmartFormField[] = [
      {
        type: 'select',
        width: 12,
        name: this.mode === 'supervisor' ? 'status' : 'action',
        label: 'Status',
        placeHolder: 'Please Select',
        selectOptionType: 'self',
        selectOptions:
          this.mode === 'supervisor'
            ? this.update_SuperStatus
            : this.update_status,
      },
      {
        type: 'textarea',
        name: 'hos_remarks',
        width: 12,
        label: 'Remarks',
        hideFunction: () => this.mode !== 'hos',
      },
      {
        type: 'textarea',
        name: 'hod_remarks',
        width: 12,
        label: 'Remarks',
        hideFunction: () => this.mode !== 'hod',
      },
      {
        type: 'textarea',
        name: 'ad_remarks',
        width: 12,
        label: 'Remarks',
        hideFunction: () => this.mode !== 'ad',
      },
      {
        type: 'textarea',
        name: 'gd_remarks',
        width: 12,
        label: 'Remarks',
        hideFunction: () => this.mode !== 'gd',
      },
      {
        type: 'button',
        label: 'Update',
        name: 'Submit',
        width: 12,
        buttonClass: 'smart-action-button is-fullwidth',
        buttonType: 'button',
        buttonSubmitType: 'submit',
        leftIcon: 'fa-check',
        buttonFunction: (data: any) => {
          this.updateDate(data);
        },
        hideFunction: (item: any, getValue: any) => {
          let id = getValue('ID') !== undefined ? parseInt(getValue('ID')) : 0;
          return id < 1 ? true : false;
        },
      },
    ];

    let formconfig: SmartFormNewConfig = {
      name: 'Role list form',
      SmartFields: form_fileds,
    };
    return formconfig;
  }

  viewFormConfig() {
    let form_fileds: SmartFormField[] = [
      {
        type: 'text',
        name: 'title',
        width: 6,
        label: 'Title',
        leftIcon: 'fa fa-heading',
        placeHolder: 'Title',
        validations: [
          {
            type: 'required',
            msg: 'Title is Required',
          },
        ],
      },
      {
        type: 'textarea',
        name: 'description',
        width: 6,
        label: 'Description',
        placeHolder: 'Description',
        validations: [
          {
            type: 'required',
            msg: 'Description is Required',
          },
        ],
      },
      {
        type: 'text',
        name: 'location',
        width: 6,
        label: 'Location',
        leftIcon: 'fa fa-location-dot',
        placeHolder: 'Location',
        validations: [
          {
            type: 'required',
            msg: 'Location is Required',
          },
        ],
      },
    ];

    let formconfig: SmartFormNewConfig = {
      name: 'Role list form',
      SmartFields: form_fileds,
    };
    return formconfig;
  }

  viewForm(data: any = null) {
    let options = {
      title: 'Details',
      template: this.viewform,
    };
    let dialog_options = default_form_dialog(options);
    dialog_options.width = 70;
    this.smartDialog.openDialog(dialog_options);
  }

  openViewForm(data) {
    let id = data.ID !== undefined ? data.ID : 0;
    let get_one = get_api_route('SITE_TEMPORARY_ADVANCE_ONE');
    this.api.smartPost(get_one, { id: id }).subscribe((res: any) => {
      this.viewData = res;
      this.viewForm(data);
    });
  }

  openForm(data: any = null) {
    let options = {
      title: 'Temporary Advance Settlement Form',
      template: this.createform,
    };
    let dialog_options = default_form_dialog(options);
    dialog_options.width = 70;
    this.smartDialog.openDialog(dialog_options);
  }

  editForm(data: any = null) {
    let options = {
      title: 'Temporary Advance Update Form',
      template: this.editform,
    };
    let dialog_options = default_form_dialog(options);
    dialog_options.width = 100;
    this.smartDialog.openDialog(dialog_options);
  }

  openEditForm(data) {
    let id = data.ID !== undefined ? data.ID : 0;
    let get_one = get_api_route('SITE_TEMPORARY_ADVANCE_ONE');
    this.api.smartPost(get_one, { id: id }).subscribe((res: any) => {
      this.editData = res;
      this.editForm();
    });
  }

  openAppForm(data) {
    let id = data.ID !== undefined ? data.ID : 0;
    let get_one = get_api_route('SITE_TEMPORARY_ADVANCE_ONE');
    this.api.smartPost(get_one, { id: id }).subscribe((res: any) => {
      this.editData = res;
      this.editForm();
    });
  }

  delete_one() {
    let deleteUrl = get_api_route('SITE_TEMPORARY_ADVANCE_DELETE_ONE');
    this.api.smartPost(deleteUrl, { id: this.selectedId }).subscribe((data) => {
      this.notify.success('Deleted successfully');
      this.getTableData();
    });
  }

  openDeleteCustomDialog() {
    let dialog_options = default_delete_dialog(
      'Do you want to Delete?',
      'The Action Cannot Be Reverted'
    );
    this.smartDialog.openDialog(dialog_options).confirmed.subscribe((data) => {
      if (data.action == 'yes') {
        this.delete_one();
      }
    });
  }

  openApproveCustomDialog(msg: string, action: string) {
    let dialog_options = default_delete_dialog(msg);
    this.smartDialog.openDialog(dialog_options).confirmed.subscribe((data) => {
      if (data.action == 'yes') {
        this.app_status_update_one(action);
      }
    });
  }

  app_status_update_one(status: string) {
    let deleteUrl = get_api_route('SITE_TEMPORARY_ADVANCE_UPDATE_APP');
    this.api
      .smartPost(deleteUrl, { id: this.selectedId, action: status })
      .subscribe((data) => {
        this.notify.success('Updated Successfully');
        this.getTableData();
      });
  }

  submitData(data) {
    const payload = {
      title: data.title,
      advance_amount: Number(data.advance_amount),
      balance: Number(data.balance),
      stock_reg_no: data.stock_reg_no,
      description: data.description,
    };

    this.api
      .smartPost('SITE_TEMPORARY_ADVANCE_INSERT', data)
      .subscribe((res: any) => {
        this.smartDialog.closeDialog();
        this.notify.success('Submitted successfully');
        this.getTableData();
      });
  }

  updateDate(data) {
    let id = data.ID !== undefined ? data.ID : 0;
    data['id'] = id;

    let update_url = 'SITE_TEMPORARY_ADVANCE_UPDATE';

    if (this.mode === 'hos') {
      update_url = 'SITE_TEMPORARY_ADVANCE_UPDATE_HOS';
    } else if (this.mode === 'hod') {
      update_url = 'SITE_TEMPORARY_ADVANCE_UPDATE_HOD';
    } else if (this.mode === 'ad') {
      update_url = 'SITE_TEMPORARY_ADVANCE_UPDATE_AD';
    } else if (this.mode === 'supervisor') {
      update_url = 'SITE_TEMPORARY_ADVANCE_UPDATE_SUPERVISOR';
    } else if (this.mode === 'gd') {
      update_url = 'SITE_TEMPORARY_ADVANCE_UPDATE_GD';
    }

    let api_url = get_api_route(update_url);

    this.api.smartPost(api_url, data).subscribe((res: any) => {
      this.notify.success('Updated successfully');
      this.smartDialog.closeDialog();
      this.getTableData();
    });
  }

  status_disp = [
    {
      comp: '5',
      tagClass: 'is-link is-dark',
      tagText: 'Submitted... Waiting for Supervisor',
    },
    {
      comp: '10',
      tagClass: 'is-link is-dark',
      tagText: 'Submitted... Waiting for HOS',
    },
    {
      comp: '15',
      tagClass: 'is-success',
      tagText: 'Waiting for HOD',
    },
    {
      comp: '20',
      tagClass: 'is-info',
      tagText: 'Waiting for AD',
    },
    {
      comp: '25',
      tagClass: 'is-primary',
      tagText: 'Waiting for GD',
    },
    {
      comp: '14',
      tagClass: 'is-danger',
      tagText: 'Rejected by HOS',
    },
    {
      comp: '19',
      tagClass: 'is-danger',
      tagText: 'Rejected by HOD',
    },
    {
      comp: '24',
      tagClass: 'is-danger',
      tagText: 'Rejected by AD',
    },
    {
      comp: '29',
      tagClass: 'is-danger',
      tagText: 'Rejected by GD',
    },
    {
      comp: '30',
      tagClass: 'is-success',
      tagText: 'Approved by GD',
    },
    {
      comp: '35',
      tagClass: 'is-success',
      tagText: 'Completed',
    },
  ];

  get_status_disp(status) {
    return this.status_disp.filter((item) => item.comp == status)[0]?.tagText;
  }
}