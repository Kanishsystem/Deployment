import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewFormComponetComponent } from './radiology-componet.component';

describe('NewFormComponetComponent', () => {
  let component: NewFormComponetComponent;
  let fixture: ComponentFixture<NewFormComponetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NewFormComponetComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NewFormComponetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
