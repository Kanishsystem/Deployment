import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MbookIssueComponent } from './mbook-issue.component';

describe('MbookIssueComponent', () => {
  let component: MbookIssueComponent;
  let fixture: ComponentFixture<MbookIssueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MbookIssueComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MbookIssueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
