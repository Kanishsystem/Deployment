import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AcvandlationComplaintsComponent } from './acvandlation-complaints.component';

describe('AcvandlationComplaintsComponent', () => {
  let component: AcvandlationComplaintsComponent;
  let fixture: ComponentFixture<AcvandlationComplaintsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AcvandlationComplaintsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AcvandlationComplaintsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
