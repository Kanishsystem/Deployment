import { Component, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CommonService } from 'src/app/api-services/common/common.service';
import { NotifyService } from 'src/app/api-services/common/notify.service';
import { intervalToDuration } from 'date-fns';
import { SmartapiService } from 'src/app/api-services/smartapi.service';
import {
  SmartFormField,
  SmartFormNewConfig,
} from 'src/app/shared/core/SmartInterfaces/SmartFormNewInterface';
import {
  SmartTableColumnConfig,
  SmartTableConfig,
  SmartTableMainConfig,
} from 'src/app/shared/core/SmartInterfaces/SmartTableNewInterface';
import { SmartDialogService } from 'src/app/shared/core/services/smart-dialog.service';
import {
  default_delete_dialog,
  default_form_dialog,
  default_iframe_dialog,
} from '../../helpers/site-defaults';
import { get_api_route } from 'src/app/api-services/api-router';

@Component({
  selector: 'app-mbook',
  templateUrl: './mbook.component.html',
  // styleUrl: './mbook.component.css'
})
export class MbookComponent {
  @ViewChild('createform') createform: any;
  @ViewChild('editform') editform: any;
  @ViewChild('viewform') viewform: any;
  @ViewChild('subTemplate', { static: true }) subTemplate: TemplateRef<any>;
  constructor(
    private modalService: NgbModal,
    private api: SmartapiService,
    private route: ActivatedRoute,
    private smartDialog: SmartDialogService,
    private common: CommonService,
    private notify: NotifyService
  ) {}

  tableData: any;
  entry_data: any;
  //
  tableConfigNew: SmartTableConfig;
  //
  editData: any;
  viewData: any;
  formData: any;
  ra_entry_data: any;
  mbookData: any;
  mode: string = '';
  //
  processSelection: string = '';
  selectionButton: boolean = false;
  actionTypes = [
    { value: 'wait', label: 'Waiting' },
    { value: 'process', label: 'Processed' },
  ];
  selectedId: number = 0;
  mode_data = {
    emp: {
      title: ' My MBook/ Work order ',
      url: 'SITE_MBOOK_GET_ALL_USER',
    },

    app: {
      title: 'MBook / Work order Entry-Approval',
      url: '',
    },
    admin: {
      title: 'MBook / Work order Entry-Admin',
      url: 'SITE_MBOOK_GET_ALL',
    },
    hos: {
      title: ' MBook / Work order Approval- HOS',
      url: 'SITE_MBOOK_HOS_GET_ALL',
    },
    hod: {
      title: '  MBook / Work order Approval - HOD',
      url: 'SITE_MBOOK_HOD_GET_ALL',
    },
    ad: {
      title: '  MBook / Work order Approval - AD',
      url: 'SITE_MBOOK_AD_GET_ALL',
    },
    gd: {
      title: ' MBook / Work order Approval - GD',
      url: 'SITE_MBOOK_GD_GET_ALL',
    },
  };
  /**
   * get mod data
   */
  get modeData() {
    return this.mode_data[this.mode] !== undefined
      ? this.mode_data[this.mode]
      : null;
  }

  get siteTitle() {
    return this.modeData?.title;
  }

  actionChange() {
    this.getTableData();
    this.createTable();
  }

  getTableData() {
    let tableUrl = get_api_route(this.modeData?.url);
    if (this.processSelection.length > 3) {
      tableUrl += '/' + this.processSelection;
    }
    this.api.smartGet(tableUrl).subscribe((res: any) => {
      this.tableData = res;
    });
  }

  ngOnInit(): void {
    this.mode = this.route.snapshot.data.mode;

    if (this.mode !== 'emp' && this.mode !== 'supervisor') {
      this.processSelection = 'wait';
      this.selectionButton = true;
    }
    this.createTable();
    this.getTableData();
    // this.getIssueOneData("")
  }
  get totalRA(): number {
    return this.entry_data.reduce((sum, entry) => sum + entry.ra_amount, 0);
  }

  get balance(): number {
    return this.formData?.work_order_value - this.totalRA || 0;
  }

  getTableConfig() {
    if (
      this.mode === 'admin' ||
      this.mode === 'hod' ||
      this.mode === 'hos' ||
      this.mode === 'ad' ||
      this.mode === 'gd'
    ) {
      return this.getAdminTableConfig();
    } else if (this.mode === 'app') {
      return this.getAppTableConfig();
    } else if (this.mode === 'supervisor') {
      return this.getSupervisorTableConfig();
    } else {
      return this.getUserTableConfig();
    }
  }

  getFilterConfig() {
    if (this.mode === 'admin' || this.mode === 'app') {
      return this.getAdminFilter();
    } else {
      return this.getUserFilter();
    }
  }

  createTable() {
    let table_config: SmartTableMainConfig = {
      name: 'MBook',
      title: 'Vendors Details',
      table_class: 'smart-responsive',
      download: true,
      showentries: true,
      currentpage: false,
      pagination: true,
      colsearch: true,
      search: true,
      showingentries: true,
      showEntriesClass: 'is-8',
      search_bar_placeholder: 'Search Mbook ',
      searchBarClass: 'col-4 ',
      buttonBarClass: 'col-1 d-flex justify-content-end',
      no_results: {
        title: 'No Mbook ',
        sub_title: 'Create a New Mbook ',
        icon: 'fa fa-book',
      },
    };

    this.tableConfigNew = {
      tableconfig: table_config,
      config: this.getTableConfig(),
      filterConfig: this.getFilterConfig(),
      filterData: {
        from_date: this.common.addDays(-30),
        to_date: this.common.currentDate(),
      },
    };
  }

  getAdminFilter() {
    let filterConfig: SmartFormField[] = [
      {
        type: 'text',
        width: 12,
        name: 'title',
        label: 'MBook ',
        // leftIcon: 'fa-user',
        placeHolder: 'MBook  Title',
      },

      {
        type: 'text',
        width: 12,
        name: 'created_by',
        placeHolder: 'Requester',
        label: 'Requester',
      },
      {
        type: 'text',
        width: 12,
        name: 'location',
        placeHolder: 'Location',
        label: 'Location',
      },
      {
        type: 'date',
        width: 6,
        label: 'From Date',
        name: 'from_date',
        rightIcon: 'fa-calendar',
        placeHolder: 'From Date',
        filterSettings: {
          type: 'DATE_FROM',
          field_name: 'created_time',
        },
      },
      {
        type: 'date',
        width: 6,
        label: 'To Date',
        name: 'to_date',
        rightIcon: 'fa-calendar',
        placeHolder: 'To Date',
        filterSettings: {
          type: 'DATE_TO',
          field_name: 'created_time',
        },
      },
    ];
    return filterConfig;
  }

  getUserFilter() {
    let filterConfig: SmartFormField[] = [
      {
        type: 'text',
        width: 12,
        name: 'title',
        label: ' Title',
        placeHolder: ' Title',
      },
    ];
    return filterConfig;
  }
  getSupervisorFilter() {
    let filterConfig: SmartFormField[] = [
      {
        type: 'text',
        width: 12,
        name: 'title',
        label: ' Title',
        // leftIcon: 'fa-user',
        placeHolder: ' Title',
      },

      {
        type: 'text',
        width: 12,
        name: 'created_by',
        placeHolder: 'Requester',
        label: 'Requester',
      },
    ];
    return filterConfig;
  }
  getTableColumns(req) {
    let tableColumns: { [key: string]: SmartTableColumnConfig } = {
      sno: {
        type: 'sno',
        title: 'S.No',
        tbody: 's_no',
      },
      mbook_number: {
        type: 'db',
        title: 'MBook Number',
        tbody: 'mbook_number',
      },
      mbook_title: {
        type: 'db',
        title: 'Name of Work',
        tbody: 'title',
      },
      file_type: {
        type: 'db',
        title: 'File Type',
        tbody: 'file_type',
      },
      ra_number: {
        type: 'db',
        title: 'RA Number',
        tbody: 'ra_number',
      },
      ra_amount: {
        type: 'db',
        title: 'RA Amount',
        tbody: 'ra_amount',
      },
      requester: {
        type: 'date',
        title: 'Date of Issue',
        tbody: 'date_of_issue',
        customFormat: true,
        format: 'dd-MM-YYYY',
      },
      requester_name: {
        type: 'db',
        title: 'Requester',
        tbody: 'created_by',
      },

      status: {
        type: 'tag',
        title: 'Status',
        tbody: 'entry_status',
        tagCond: [
          {
            comp: '10',
            tagClass: 'is-link is-dark',
            tagText: 'Submitted... Waiting for HOS',
          },
          {
            comp: '15',
            tagClass: 'is-success',
            tagText: 'Waiting for HOD',
          },
          {
            comp: '20',
            tagClass: 'is-info',
            tagText: 'Waiting for AD',
          },
          {
            comp: '25',
            tagClass: 'is-primary',
            tagText: 'Waiting for GD',
          },
          {
            comp: '14',
            tagClass: 'is-danger',
            tagText: 'Rejected by HOS',
          },
          {
            comp: '19',
            tagClass: 'is-danger',
            tagText: 'Rejected by HOD',
          },
          {
            comp: '24',
            tagClass: 'is-danger',
            tagText: 'Rejected by AD',
          },
          {
            comp: '29',
            tagClass: 'is-danger',
            tagText: 'Rejected by GD',
          },
          {
            comp: '30',
            tagClass: 'is-success',
            tagText: 'Approved by GD',
          },
          {
            comp: '35',
            tagClass: 'is-success',
            tagText: 'Completed',
          },
        ],
      },
      fileButton: {
        type: 'buttons',
        title: 'Attachment',
        btn_config: [
          {
            type: 'button',
            class: ['has-text-info'],
            btn_type: 'icon',
            icon: ['fa fa-file-pdf-o'],
            btn_func: (data) => {
              this.openPdfView(data);
            },
            // btn_show: (data) => {
            //   return data['doc_loc'] && data['doc_loc'] === true
            //     ? true
            //     : false;
            // },
          },
        ],
      },
      buttons: {
        type: 'buttons',
        title: 'Action',
        btn_config: [
          {
            type: 'button',
            label: '',
            class: ['has-text-primary', 'is-small'],

            btn_type: 'icon',
            icon: ['fa-eye'],
            btn_func: (data) => {
              //console.log("data ", data);
              this.openViewForm(data);
            },
          },
          {
            type: 'button',
            class: ['has-text-info', 'is-small'],
            btn_type: 'icon',
            icon: ['fa-pencil-square-o'],
            btn_func: (data) => {
              // here impliments
              this.openEditForm(data);
            },
          },
        ],
      },
      buttonsApp: {
        type: 'buttons',
        title: 'Actions',
        btn_config: [
          {
            type: 'button',
            label: '',
            class: ['has-text-success', 'is-small'],
            btn_type: 'icon',
            icon: ['fa fa-check'],
            btn_func: (data) => {
              //console.log("data ", data);
              this.selectedId = data['ID'] !== undefined ? data['ID'] : 0;
              this.openApproveCustomDialog(
                'Do you Want to Approve the Mbook Entry'
              );
            },
            // btn_show:()=>{
            //   return this.processSelection=="wait" ? true : false;
            // }
          },
          {
            type: 'button',
            label: '',
            class: ['has-text-danger', 'is-small'],
            btn_type: 'icon',
            icon: ['fa fa-times'],
            btn_func: (data) => {
              //console.log("data ", data);
              this.selectedId = data['ID'] !== undefined ? data['ID'] : 0;
              this.openApproveCustomDialog(
                'Do you Want to Reject the Mbook Entry'
              );
            },
            btn_show: () => {
              return this.processSelection == 'wait' ? true : false;
            },
          },
        ],
      },
      user_buttons: {
        type: 'buttons',
        title: 'Actions',
        btn_config: [
          {
            type: 'button',
            label: '',
            class: ['has-text-primary', 'is-small'],

            btn_type: 'icon',
            icon: ['fa-eye'],
            btn_func: (data) => {
              //console.log("data ", data);
              this.openViewForm(data);
            },
          },

          {
            type: 'button',
            label: '',
            class: ['has-text-danger', 'is-small'],
            btn_type: 'icon',
            icon: ['fa fa-trash'],
            btn_func: (data) => {
              //console.log("data ", data);
              this.selectedId = data['ID'] !== undefined ? data['ID'] : 0;
              this.openDeleteCustomDialog();
            },
            btn_show: (data) => {
              return data?.entry_status === 10 ? true : false;
            },
          },
        ],
      },
    };

    let output_columns: SmartTableColumnConfig[] = [];
    req.forEach((element) => {
      let column: SmartTableColumnConfig =
        tableColumns[element[0]] !== undefined
          ? tableColumns[element[0]]
          : null;
      //console.log("columns " , column);
      if (column !== null && element[1] !== undefined) {
        column['width'] = element[1] + '%';
      }
      if (column != null) {
        output_columns.push(column);
      }
    });
    return output_columns;
  }

  getAppTableConfig() {
    let columns = [
      ['sno', 5],
      ['mbook_number', 15],
      ['mbook_title', 30],
      ['requester_name', 15],
      ['requester', 10],

      ['date_of_issue', 10],
      ['status', 10],
      ['buttonsApp', 5],
    ];
    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }
  getSupervisorTableConfig() {
    let columns = [
      ['sno', 5],
      ['mbook_number', 10],
      ['mbook_title', 15],
      ['file_type', 10],
      ['ra_number', 10],
      ['ra_amount', 10],
      ['requester_name', 15],
      ['requester', 10],
      ['date_of_issue', 10],
      ['status', 10],
    ];

    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }
  getAdminTableConfig() {
    let columns = [
      ['sno', 5],
      ['mbook_number', 10],
      ['mbook_title', 10],
      ['file_type', 10],
      ['ra_number', 10],
      ['ra_amount', 10],
      ['requester_name', 15],
      ['requester', 10],
      ['date_of_issue', 10],
      ['fileButton', 5],
      ['status', 10],
      // ['file_type', 5],
    ];

    if (this.processSelection === 'wait' && this.mode !== 'admin') {
      columns.push(['buttons', 15]);
    }

    let table_body_config = this.getTableColumns(columns);

    return table_body_config;
  }

  getUserTableConfig() {
    let columns = [
      ['sno', 5],
      ['mbook_number', 20],
      ['mbook_title', 30],
      ['file_type', 10],
      ['ra_number', 10],
      ['ra_amount', 10],
      ['requester', 10],
      ['status', 10],
      ['fileButton', 5],
      ['user_buttons', 10],
    ];
    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }

  createFormConfig() {
    let form_fileds: SmartFormField[] = [
      {
        type: 'select',
        width: 4,
        label: 'Mbook No.',
        name: 'sd_mbook_issue_id',
        selectOptionType: 'api',
        selectOptionApi: 'SITE_MBOOK_ID_SELECT_GET_ALL',
        onChange: (get_value, set_value, set_validations) => {
          let type_value = get_value('sd_mbook_issue_id');

          console.log('get value ', type_value);
          this.getIssueOneData(type_value);
          this.getAll_entire(type_value);
          this.ra_entry_data = type_value;
        },

        validations: [
          {
            type: 'required',
            msg: 'Required',
          },
        ],
      },
      {
        type: 'select',
        width: 4,
        name: 'file_type',
        label: 'File Type',
        placeHolder: 'Please Select',
        selectOptionType: 'self',
        disabled_func: true,
        selectOptions: [
          { value: 'NIQ', label: 'NIQ' },
          { value: 'NIT', label: 'NIT' },
        ],
      },
      {
        type: 'text',
        width: 4,
        label: 'Date Of Work order',
        name: 'date_of_issue',
        rightIcon: 'fa-calendar',
        placeHolder: 'Date Of Work order',
        disabled_func: true,
      },
      {
        type: 'text',
        name: 'title',
        width: 4,
        label: 'Name of Work',
        placeHolder: 'Name of Work',
        disabled_func: true,
      },

      {
        type: 'text',
        name: 'work_order_number',
        width: 4,
        label: 'Work Order Number',
        placeHolder: 'Work Order Number',
        disabled_func: true,
      },
      {
        type: 'text',
        name: 'work_order_value',
        width: 4,
        label: 'Work Order value',
        disabled_func: true,
        placeHolder: 'Work Order value',
        validations: [
          {
            type: 'required',
            msg: ' Work Order value is Required',
          },
        ],
      },
      {
        type: 'select',
        width: 4,
        name: 'budget_type',
        label: 'Budget',
        placeHolder: 'Please Select Budget',
        disabled_func: true,
        selectOptionType: 'self',
        selectOptions: [
          { value: 'Revenue', label: 'Revenue' },
          { value: 'Capital', label: 'Capital' },
          { value: 'Other', label: 'Other' },
        ],
      },
      {
        type: 'text',
        name: 'others',
        width: 4,
        label: 'Other',
        placeHolder: 'Other',
        disabled_func: true,
        hideFunction: (item, getValue) => {
          console.log('get admin Value', getValue('budget_type'));
          return getValue('budget_type') !== '3' ? true : false;
        },
      },
      {
        type: 'text',
        name: 'budget_pin',
        width: 4,
        label: 'Budget PIN',
        placeHolder: 'Budget PIN',
        disabled_func: true,
      },
      {
        type: 'text',
        width: 4,
        label: 'Start date',
        name: 'start_date',
        rightIcon: 'fa-calendar',
        placeHolder: 'Start date',

        disabled_func: true,
      },
      {
        type: 'text',
        width: 4,
        label: 'End date',
        name: 'end_date',
        rightIcon: 'fa-calendar',
        placeHolder: 'End date',
        disabled_func: true,
      },
      {
        type: 'text',
        name: 'contact_name',
        width: 4,
        label: 'Contact Name',
        disabled_func: true,
        placeHolder: 'Contact Name',
      },
      {
        type: 'text',
        name: 'technical_sanction_number',
        width: 4,
        label: 'Technical Sanction Number',
        placeHolder: 'Technical Sanction Number',
        disabled_func: true,
      },
      {
        type: 'template',
        name: 'person_details_header',
        label: 'Personnel Details',
        width: 12,
        template: this.subTemplate,
      },
      {
        type: 'text',
        name: 'ra_number',
        width: 4,
        label: 'RA Number',
        // placeHolder: 'Technical Sanction Number',
        validations: [
          {
            type: 'required',
            msg: 'RA Number is Required',
          },
        ],
      },
      {
        type: 'text',
        name: 'ra_amount',
        width: 4,
        label: 'RA Amount',
        placeHolder: '000',
        validations: [
          {
            type: 'required',
            msg: 'RA Amount is Required',
          },
        ],
      },
      {
        type: 'button',
        label: 'Submit ',
        name: 'Submit',
        width: 12,
        buttonClass: 'smart-action-button is-fullwidth',
        buttonType: 'button',
        buttonSubmitType: 'submit',
        leftIcon: 'fa-check',
        buttonFunction: (data: any) => {
          // console.log('We Get data', data);
          this.submitData(data);
        },
        // hideFunction: (item: any, getValue: any) => {
        //   let id = getValue('ID') !== undefined ? parseInt(getValue('ID')) : 0;
        //   return id > 0 ? true : false;
        // },
      },

      // {
      //   type: 'button',
      //   label: 'Update ',
      //   name: 'Submit',
      //   width: 12,
      //   buttonClass: 'smart-action-button is-fullwidth',
      //   buttonType: 'button',
      //   buttonSubmitType: 'submit',
      //   leftIcon: 'fa-check',
      //   buttonFunction: (data: any) => {
      //     this.updateDate(data);
      //   },
      //   hideFunction: (item: any, getValue: any) => {
      //     let id = getValue('ID') !== undefined ? parseInt(getValue('ID')) : 0;
      //     return id < 1 ? true : false;
      //   },
      // },
    ];

    let formconfig: SmartFormNewConfig = {
      name: 'Book List form',
      SmartFields: form_fileds,
    };
    return formconfig;
  }

  editFormConfig() {
    let form_fileds: SmartFormField[] = [
      {
        type: 'select',
        width: 12,
        name: 'action',
        label: 'Status',
        placeHolder: 'Please Select',
        selectOptionType: 'self',

        selectOptions: [
          { value: 'approve', label: 'Approved' },
          { value: 'reject', label: 'Rejected' },
        ],
        validations: [
          {
            type: 'required',
            msg: 'Required',
          },
        ],
      },
      {
        type: 'textarea',
        name: 'remarks',
        width: 12,
        label: 'Remarks',
      },
      {
        type: 'button',
        label: 'Update',
        name: 'Submit',
        width: 12,
        buttonClass: 'smart-action-button is-fullwidth',
        buttonType: 'button',
        buttonSubmitType: 'submit',
        leftIcon: 'fa-check',
        buttonFunction: (data: any) => {
          this.updateDate(data);
        },
        hideFunction: (item: any, getValue: any) => {
          let id = getValue('ID') !== undefined ? parseInt(getValue('ID')) : 0;
          return id < 1 ? true : false;
        },
      },
    ];

    let formconfig: SmartFormNewConfig = {
      name: 'Role list form',
      SmartFields: form_fileds,
    };
    return formconfig;
  }

  viewFormConfig() {
    let form_fileds: SmartFormField[] = [
      {
        type: 'text',
        name: 'title',
        width: 6,
        label: 'Title',
        leftIcon: 'fa fa-heading',
        placeHolder: 'Title',
        validations: [
          {
            type: 'required',
            msg: 'Title is Required',
          },
        ],
      },
    ];

    let formconfig: SmartFormNewConfig = {
      name: 'Role list form',
      SmartFields: form_fileds,
    };
    return formconfig;
  }

  viewForm(data: any = null) {
    // console.log("hello button clicked")
    // this.modalService.open(this.viewform, { size: 'lg' });
    let options = {
      title: 'Details',

      template: this.viewform,
    };
    let dialog_options = default_form_dialog(options);
    dialog_options.width = 70;
    this.smartDialog.openDialog(dialog_options);
  }
  openViewForm(data) {
    let id = data.ID !== undefined ? data.ID : 0;
    let get_one = get_api_route('SITE_MBOOK_ONE');
    this.api.smartPost(get_one, { id: id }).subscribe((res: any) => {
      // console.log('single data', res);
      this.viewData = res;
      this.viewForm(data);
      this.getAll_entire(this.viewData?.sd_mbook_issue_id?.value);
    });
  }

  getPeriodDuration(): string {
    const startDate = new Date(this.editData?.start_date);
    const endDate = new Date(this.editData?.end_date);
    console.log('END DATA', this.editData?.end_date);

    const duration = intervalToDuration({ start: startDate, end: endDate });

    const parts = [];

    if (duration.years) {
      parts.push(`${duration.years} year${duration.years > 1 ? 's' : ''}`);
    }
    if (duration.months) {
      parts.push(`${duration.months} month${duration.months > 1 ? 's' : ''}`);
    }
    if (duration.days) {
      parts.push(`${duration.days} day${duration.days > 1 ? 's' : ''}`);
    }

    console.log('over', parts.join(', '));

    return parts.join(', ') || '0 days';
  }

  openForm(data: any = null) {
    if (data != null) {
      this.formData = data;
    } else {
      this.formData = {};
    }
    let options = {
      title: 'MBook Form',

      template: this.createform,
    };
    let dialog_options = default_form_dialog(options);
    dialog_options.width = 70;
    this.smartDialog.openDialog(dialog_options);
  }
  editForm(data: any = null) {
    let options = {
      title: 'MBook Update Form',
      template: this.editform,
    };
    let dialog_options = default_form_dialog(options);
    dialog_options.width = 70;
    this.smartDialog.openDialog(dialog_options);
    // console.log('hello button clicked');
    // this.modalService.open(this.viewform, { size: 'lg' });
  }

  openEditForm(data) {
    let id = data.ID !== undefined ? data.ID : 0;
    let get_one = get_api_route('SITE_MBOOK_ONE');
    this.api.smartPost(get_one, { id: id }).subscribe((res: any) => {
      //  console.log("single data", res);
      this.editData = res;
      this.editForm();
    });
  }

  openAppForm(data) {
    let id = data.ID !== undefined ? data.ID : 0;
    let get_one = get_api_route('SITE_MBOOK_ONE');
    this.api.smartPost(get_one, { id: id }).subscribe((res: any) => {
      //  console.log("single data", res);
      this.editData = res;
      this.editForm();
    });
  }

  delete_one() {
    let deleteUrl = get_api_route('SITE_MBOOK_DELETE_ONE');
    this.api.smartPost(deleteUrl, { id: this.selectedId }).subscribe((data) => {
      this.notify.success('Deleted successfully');
      this.getTableData();
    });
  }

  openDeleteCustomDialog() {
    let dialog_options = default_delete_dialog(
      'Do you want to Delete?',
      'The Action Cannot Be Reverted'
    );
    this.smartDialog.openDialog(dialog_options).confirmed.subscribe((data) => {
      if (data.action == 'yes') {
        this.delete_one();
      }
    });
  }

  openApproveCustomDialog(msg) {
    let dialog_options = default_delete_dialog(msg);
    this.smartDialog.openDialog(dialog_options).confirmed.subscribe((data) => {
      if (data.action == 'yes') {
        this.app_status_update_one('approve');
      }
    });
  }

  app_status_update_one(status: string) {
    // url needs to be changed
    let deleteUrl = get_api_route('SITE_MBOOK_DELETE_ONE');
    this.api
      .smartPost(deleteUrl, { id: this.selectedId, action: status })
      .subscribe((data) => {
        this.notify.success('Deleted successfully');
        this.getTableData();
      });
  }

  // getTableData() {
  //   this.api.smartGet('SITE_ELECTRICAL_GET_ALL').subscribe((res: any) => {
  //     this.tableData = res;
  //   });
  // }

  submitData(data) {
    this.api.smartPost('SITE_MBOOK_INSERT', data).subscribe((res: any) => {
      this.smartDialog.closeDialog();
      this.notify.success('Submitted successfully');
      // this.notify.error('You cannot add a new entry. A previous entry is still in waiting status.');
      this.getTableData();
    });
  }

  updateDate(data) {
    let id = data.ID !== undefined ? data.ID : 0;
    let update_url = 'SITE_MBOOK_UPDATE';

    if (this.mode === 'hos') {
      update_url = 'SITE_MBOOK_UPDATE_HOS';
    } else if (this.mode === 'hod') {
      update_url = 'SITE_MBOOK_UPDATE_HOD';
    } else if (this.mode === 'ad') {
      update_url = 'SITE_MBOOK_UPDATE_AD';
    } else if (this.mode === 'gd') {
      update_url = 'SITE_MBOOK_UPDATE_GD';
    }

    let api_url = get_api_route(update_url);

    data['id'] = id;
    this.api.smartPost(api_url, data).subscribe((res: any) => {
      //  console.log('data ', res);
      this.notify.success('Updated successfully');
      this.smartDialog.closeDialog();
      this.getTableData();
    });
  }
  openPdfView(data) {
    let id = data?.ID !== undefined ? data?.ID : 0;
    let options = {
      title: 'PDF Viewer',
      iframe: get_api_route('SITE_MBOOK_ISSUE_GET_DOC'),
    };
    let dialog_options = default_iframe_dialog(options);
    dialog_options.iframe_payload = { id: data?.sd_mbook_issue_id };
    this.smartDialog.openDialog(dialog_options);
  }
  status_disp = [
    {
      comp: '10',
      tagClass: 'is-link is-dark',
      tagText: 'Submitted... Waiting for HOS',
    },
    {
      comp: '15',
      tagClass: 'is-success',
      tagText: 'Waiting for HOD',
    },
    {
      comp: '20',
      tagClass: 'is-info',
      tagText: 'Waiting for AD',
    },
    {
      comp: '25',
      tagClass: 'is-primary',
      tagText: 'Waiting for GD',
    },
    {
      comp: '14',
      tagClass: 'is-danger',
      tagText: 'Rejected by HOS',
    },
    {
      comp: '19',
      tagClass: 'is-danger',
      tagText: 'Rejected by HOD',
    },
    {
      comp: '24',
      tagClass: 'is-danger',
      tagText: 'Rejected by AD',
    },
    {
      comp: '29',
      tagClass: 'is-danger',
      tagText: 'Rejected by GD',
    },
    {
      comp: '30',
      tagClass: 'is-success',
      tagText: 'Approved by GD',
    },
    {
      comp: '35',
      tagClass: 'is-success',
      tagText: 'Approved',
    },
  ];

  get_status_disp(status) {
    return this.status_disp.filter((item) => item.comp == status)[0]?.tagText;
  }

  getIssueOneData(data) {
    let id = data ? data : 0;
    let get_one = get_api_route('SITE_MBOOK_ISSUE_ONE');
    this.api.smartPost(get_one, { id: id }).subscribe((res: any) => {
      // console.log('single data', res);
      this.formData = res;
    });
  }
  getAll_entire(data) {
    let id = data ? data : 0;
    let get_one = get_api_route('SITE_MBOOK_GET_ALL_ENTRIES');
    this.api
      .smartPost(get_one, { mbook_issue_id: id })
      .subscribe((res: any) => {
        // console.log('single data', res);
        this.entry_data = res;
      });
  }
}
