import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MbookComponent } from './mbook.component';

describe('MbookComponent', () => {
  let component: MbookComponent;
  let fixture: ComponentFixture<MbookComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MbookComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MbookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
