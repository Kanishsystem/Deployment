import { Component, ViewChild, TemplateRef } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { get_api_route } from 'src/app/api-services/api-router';
import { CommonService } from 'src/app/api-services/common/common.service';
import { NotifyService } from 'src/app/api-services/common/notify.service';
import { SmartapiService } from 'src/app/api-services/smartapi.service';
import { SmartDialogService } from 'src/app/shared/core/services/smart-dialog.service';
import {
  SmartFormField,
  SmartFormNewConfig,
} from 'src/app/shared/core/SmartInterfaces/SmartFormNewInterface';
import {
  SmartTableColumnConfig,
  SmartTableConfig,
  SmartTableMainConfig,
} from 'src/app/shared/core/SmartInterfaces/SmartTableNewInterface';
import {
  ExcelExportService,
  ExportOptions,
} from 'src/app/shared/services/excel-export.service';
import { PdfExportService } from 'src/app/shared/services/pdf-export.service';
import { format } from 'date-fns';

// import {
//   PdfExportService,
// } from 'src/app/shared/services/export-pdf.service';
@Component({
  selector: 'app-mis-report',
  // imports: [],
  templateUrl: './mis-report.component.html',
  // styleUrl: './mis-report.component.css'
  styleUrls: ['./mis-report.component.css'],
})
export class MisReportComponent {
  @ViewChild('createform') createform: any;
  @ViewChild('personDetailsTemplate') personDetailsTemplate!: TemplateRef<any>;
  @ViewChild('actionsTemplate') actionsTemplate!: TemplateRef<any>;
  constructor(
    private modalService: NgbModal,
    private api: SmartapiService,
    private notify: NotifyService,
    private smartDialog: SmartDialogService,
    private common: CommonService,
    private excelExportService: ExcelExportService,
    private pdfExportService: PdfExportService
  ) {}
  formData: any;
  typeData: string;
  tableData: any;
  //
  new_type: any;
  sub_cat_type: any;
  tableConfigNew: SmartTableConfig;
  // subOptions: any;

  // subCatUrl: any;

 exportExcel() {
  const columns = this.tableConfigNew.config.map((col) => ({
    index: col.tbody,
    title: col.title,
  }));


  const dateFields = [
      'created_time',
      'closed_date',
      'meet_date',
      'last_modified_time',
    ];

  const dataWithSno = this.tableData.map((row, index) => {
    const formattedRow: any = {
      ...row,
      s_no: index + 1,
    };

    dateFields.forEach((field) => {
      if (formattedRow[field]) {
        try {
          const date = new Date(formattedRow[field]);
          formattedRow[field] = format(date, 'dd-MM-yyyy');
        } catch (e) {
          console.warn(`Invalid date in field ${field}:`, formattedRow[field]);
        }
      }
    });

    return formattedRow;
  });

  const today = new Date();
  const formattedDate = format(today, 'dd-MM-yyyy');

  const options: ExportOptions = {
    columns: columns,
    data: dataWithSno,
    filename: `${this.typeData}-report-${formattedDate}.xlsx`,
    sheetTitle: `${this.typeData} Report - ${formattedDate}`,
  };

  this.excelExportService.exportToExcel(options);
}
  exportPdf() {
    const columns = this.tableConfigNew.config.map((col) => ({
      index: col.tbody,
      title: col.title,
    }));
    const dateFields = [
      'created_time',
      'closed_date',
      'meet_date',
      'last_modified_time',
    ];

    const dataWithSno = this.tableData.map((row, index) => {
      const formattedRow: any = {
        ...row,
        s_no: index + 1,
      };

      // Format date fields using date-fns
      dateFields.forEach((field) => {
        if (formattedRow[field]) {
          try {
            const date = new Date(formattedRow[field]);
            formattedRow[field] = format(date, 'dd-MM-yyyy');
          } catch (e) {
            console.warn(
              `Invalid date in field ${field}:`,
              formattedRow[field]
            );
          }
        }
      });

      return formattedRow;
    });

    const today = new Date();
    const formattedDate = format(today, 'dd-MM-yyyy');

    const options: ExportOptions = {
      columns: columns,
      data: dataWithSno,
      filename: `${this.typeData}-report-${formattedDate}.pdf`,
      sheetTitle: `${this.typeData} Report - ${formattedDate}`,
    };

    this.pdfExportService.exportToPdf(options);
  }
  ngOnInit(): void {
    // this.createTable();
    //  this.getTableData();
    // this.subOptions=  this.getApiRouteByType(this.new_type)
    // console.log("sub Options",this.subOptions)
  }

  getApiRouteByType(type: any): string {
    switch (type) {
      case 'complaint':
        return get_api_route('SITE_REPORT_COMPLAINT_TYPE_GET_ALL');
      // case 'requisition':
      //   return get_api_route('SITE_REQUISITION_ONE');
      case 'meeting_rooms':
        return get_api_route('SITE_TYPE_GET_ALL_SELECT') + 'meetTypes';
      // case 'mbook_file_budget':
      //   return get_api_route('SITE_MBOOK_ONE');
      case 'committee':
        return get_api_route('SITE_REPORT_COMMITTEE_TYPE_GET_ALL');
      case 'document':
        return get_api_route('SITE_REPORT_DOCUMENT_TYPE_GET_ALL');
      default:
        return 'SITE_REPORT_COMPLAINT_TYPE_GET_ALL';
    }
  }
  getApiRouteByReportType(type: any): string {
    switch (type) {
      case 'complaint':
        switch (this.sub_cat_type) {
          case 'network':
            return get_api_route('SITE_REPORT_NET_COMPLAINT');
          case 'telephone':
            return get_api_route('SITE_REPORT_TEL_COMPLAINT');
          case 'electrical':
            return get_api_route('SITE_REPORT_ELC_COMPLAINT');
          default:
            return get_api_route('SITE_REPORT_COMPLAINT');
        }
      case 'requisition':
        return get_api_route('SITE_REPORT_REQUISITION');
      case 'meeting_rooms':
        return get_api_route('SITE_REPORT_MEETING_ROOM');
      case 'mbook_file_budget':
        return get_api_route('SITE_REPORT_MBOOK');
      case 'temporary_advance':
        return get_api_route('SITE_REPORT_TEMPORARY');
      case 'committee':
        return get_api_route('SITE_REPORT_COMMITTEE');
      case 'document':
        return get_api_route('SITE_REPORT_DOCUMENT');
      default:
        return '';
    }
  }

  getReport(data: any) {
    const get_one = this.getApiRouteByReportType(data?.report_type);
    const modifiedData = {
      ...data,
      subcategory: {
        value: data.subcategory,
        label: data.subcategory,
      },
    };
    this.api.smartPost(get_one, modifiedData).subscribe((res: any) => {
      this.tableData = res;
    });
  }

  subOptions: any[] = [];
  mainComplaint = [
    { value: 'electrical', label: 'Electrical ' },
    { value: 'telephone', label: 'Telephone ' },
    { value: 'network', label: 'Network ' },
  ];
  storeSubOptions(options: any[]) {
    this.subOptions.length = 0;
    this.subOptions.push(...options);
    if (this.new_type === 'complaint') {
      this.subOptions.unshift(...this.mainComplaint);
    }
    console.log('Updated subOptions:', this.subOptions);
  }

  getSubCategory(type_value, set_value?) {
    const get_one = this.getApiRouteByType(type_value);

    this.api.smartGet(get_one).subscribe((res: any) => {
      this.storeSubOptions([]);
      this.storeSubOptions(res);

      if (set_value) {
        set_value('subcategory', null);
      }
    });
  }

  createFormConfig() {
    let form_fileds: SmartFormField[] = [
      {
        type: 'select',
        width: 3,
        name: 'report_type',
        label: 'Report Type',
        placeHolder: 'Please Select ',
        selectOptionType: 'self',
        selectOptions: [
          { value: 'complaint', label: 'Complaint' },
          { value: 'requisition', label: 'Requisition' },
          { value: 'meeting_rooms', label: 'Meeting Rooms' },
          { value: 'temporary_advance', label: 'Temporary Advance' },
          { value: 'document', label: 'Document' },
          { value: 'committee', label: 'Committee' },
           { value: 'mbook_file_budget', label: 'MBook ' },
        ],
        validations: [
          {
            type: 'required',
            msg: 'Type is Required',
          },
        ],
        onChange: (get_value, set_value, set_validations) => {
          let type_value = get_value('report_type');
          console.log('get value type', type_value);
          this.getSubCategory(type_value, set_value);
          if (this.new_type && this.new_type !== type_value) {
            set_value('subcategory', null);
            set_value('start_date', null);
            set_value('end_date', null);
          }

          this.new_type = type_value;
        },
      },
      {
        type: 'select',
        name: 'subcategory',
        width: 3,
        label: 'Sub category',
        //  leftIcon: "fa fa-sitemap",
        placeHolder: 'Please Select',
        selectOptionType: 'self',
        selectOptions: this.subOptions,
        onChange: (get_value, set_value, set_validations) => {
          let sub_cat = get_value('subcategory');
          console.log('get sub Cat', sub_cat);

          this.sub_cat_type = sub_cat;
        },

        hideFunction: (item: any, getValue: any) => {
          return this.new_type == 'requisition' ||
            this.new_type == 'temporary_advance'||this.new_type=="mbook_file_budget"
            ? true
            : false;
        },
      },
         {
        type: 'select',
        name: 'file_type',
        width: 3,
        label: 'File Type',
        //  leftIcon: "fa fa-sitemap",
        placeHolder: 'Please Select',
        selectOptionType: 'self',
      selectOptions: [
          { value: 'NIQ', label: 'NIQ' },
          { value: 'NIT', label: 'NIT' },
        ],
   

        hideFunction: (item: any, getValue: any) => {
          return this.new_type !== 'mbook_file_budget' 
            
            ? true
            : false;
        },
      },
       {
        type: 'select',
        width: 3,
        name: 'budget_type',
        label: 'Budget',
        placeHolder: 'Please Select Budget',
        selectOptionType: 'self',
        selectOptions: [
          { value: 'Revenue', label: 'Revenue' },
          { value: 'Capital', label: 'Capital' },
          { value: 'Other', label: 'Other' },
        ],
          hideFunction: (item: any, getValue: any) => {
             return this.new_type !== 'mbook_file_budget' 
           
            ? true
            : false;
        },
      },
      {
        type: 'text',
        name: 'contact_name',
        width: 3,
        label: 'Contactor  Name',
        placeHolder: 'Contactor  Name',
        hideFunction: (item: any, getValue: any) => {
             return this.new_type !== 'mbook_file_budget' 
           
            ? true
            : false;
        },
      },
       {
        type: 'text',
        name: 'technical_sanction_number',
        width: 3,
        label: 'Technical Sanction Number',
        placeHolder: 'Technical Sanction Number',
         hideFunction: (item: any, getValue: any) => {
             return this.new_type !== 'mbook_file_budget' 
           
            ? true
            : false;
        },
      },
      
      

      {
        type: 'date',
        name: 'start_date',
        width: 2,
        label: 'Start Date',
        leftIcon: 'fa fa-calendar',
        placeHolder: 'Date',

        validations: [
          {
            type: 'required',
            msg: 'Start Date is Required',
          },
        ],
      },
      {
        type: 'date',
        name: 'end_date',
        width: 2,
        label: 'End Date',
        leftIcon: 'fa fa-calendar',
        placeHolder: 'Date',
        validations: [
          {
            type: 'required',
            msg: 'Start Date is Required',
          },
        ],
      },
      //  {
      //   type: 'template',
      //   name: 'person_details_header',
      //   label: 'Personnel Details',
      //   width: 12,
      //   template: this.personDetailsTemplate,
      // },

      {
        type: 'button',
        label: 'Submit',
        name: 'Submit',
        width: 2,
        buttonClass: 'smart-action-button is-fullwidth mt-5',
        buttonType: 'button',
        buttonSubmitType: 'submit',
        leftIcon: 'fa-check',
        buttonFunction: (data: any) => {
          //  this.submitData(data);
          this.typeData = data.report_type;
          //  this.formData = data;th

          this.createTable();
          this.getReport(data);
          console.log('new report data', data);
        },
      },
    ];

    let formconfig: SmartFormNewConfig = {
      name: 'Mis Retort Form',
      SmartFields: form_fileds,
      // formValidation:this.emailCustomValidator()
    };
    return formconfig;
  }

  ///Table details

  getTableConfig() {
    switch (this.typeData) {
      case 'complaint':
        return this.getComplaintTableConfig();
      case 'requisition':
        return this.getRequisitionTableConfig();
      case 'meeting_rooms':
        return this.getMeetingRoomTableConfig();
      case 'mbook_file_budget':
        return get_api_route('SITE_MBOOK_ONE');
      case 'temporary_advance':
        return this.getTMPTableConfig();
      case 'committee':
        return this.getCommitteeTableConfig();
      case 'document':
        return this.getDocumentTableConfig();
      default:
        return null;
    }
  }

  getTableColumns(req) {
    let tableColumns: { [key: string]: SmartTableColumnConfig } = {
      sno: {
        type: 'sno',
        title: 'S.No',
        tbody: 's_no',
      },
      complaint_title: {
        type: 'db',
        title: 'Title',
        tbody: 'title',
      },

      requester_name: {
        type: 'db',
        title: 'Requester Name',
        tbody: 'created_by',
      },

      location: {
        type: 'db',
        title: 'Location',
        tbody: 'location',
      },
      requester: {
        type: 'date',
        title: 'Date',
        tbody: 'created_time',
        customFormat: true,
        format: 'dd-MM-YYYY',
      },
      closed_date: {
        type: 'date',
        title: 'Closed Date',
        tbody: 'last_modified_time',
        customFormat: true,
        format: 'dd-MM-YYYY',
      },

      name: {
        type: 'db',
        title: 'Name',
        tbody: 'name',
      },

      description: {
        type: 'db',
        title: 'Description',
        tbody: 'description',
      },
      //meet Table
      room_name: {
        type: 'db',
        title: 'Room Name',
        tbody: 'room_name',
      },
      meet_purpose: {
        type: 'db',
        title: 'Meet Purpose',
        tbody: 'meet_purpose',
      },
      employee: {
        type: 'db',
        title: 'Requester',
        tbody: 'ename',
      },
      meet_date: {
        type: 'date',
        title: 'Date',
        tbody: 'meet_date',
        customFormat: true,
        format: 'dd-MM-YYYY',
      },
      start_time: {
        type: 'db',
        title: 'Start Time',
        tbody: 'meet_start_time',
      },
      end_time: {
        type: 'db',
        title: 'End Time',
        tbody: 'meet_end_time',
      },
      //tmp Advance
      temporary_advance_number: {
        type: 'db',
        title: 'Advance No.',
        tbody: 'temporary_advance_number',
      },
      advance_amount: {
        type: 'db',
        title: 'Advance Amount',
        tbody: 'advance_amount',
      },
      stock_reg_no: {
        type: 'db',
        title: 'Stock Reg No.',
        tbody: 'stock_reg_no',
      },
      balance: {
        type: 'db',
        title: 'Balance',
        tbody: 'balance',
      },
      //DOCuments
      doc_title: {
        type: 'db',
        title: 'Doc Title',
        tbody: 'doc_title',
      },

      upload_by: {
        type: 'db',
        title: 'Doc Title',
        tbody: 'created_by',
      },
      authors: {
        type: 'db',
        title: 'Authors',
        tbody: 'authors',
      },
    };

    let output_columns: SmartTableColumnConfig[] = [];
    req.forEach((element) => {
      let column: SmartTableColumnConfig =
        tableColumns[element[0]] !== undefined
          ? tableColumns[element[0]]
          : null;
      //console.log("columns " , column);
      if (column !== null && element[1] !== undefined) {
        column['width'] = element[1] + '%';
      }
      if (column != null) {
        output_columns.push(column);
      }
    });
    return output_columns;
  }

  getComplaintTableConfig() {
    let columns = [
      ['sno', 5],
      ['complaint_title', 25],
      ['location', 20],
      ['employee', 10],
      ['requester', 10],
      ['closed_date', 10],
    ];
    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }
  getRequisitionTableConfig() {
    let columns = [
      ['sno', 5],
      ['name', 10],
      ['description', 20],
      ['requester', 10],
    ];
    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }
  getMeetingRoomTableConfig() {
    let columns = [
      ['sno', 5],
      ['room_name', 10],
      ['meet_purpose', 20],
      ['employee', 10],
      ['meet_date', 10],
      ['start_time', 10],
      ['end_time', 10],
    ];
    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }

  getTMPTableConfig() {
    let columns = [
      ['sno', 5],
      ['temporary_advance_number', 10],
      ['complaint_title', 15],
      ['employee', 10],
      ['requester', 10],
      ['advance_amount', 10],
      ['stock_reg_no', 10],
      ['balance', 10],
    ];
    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }
  getCommitteeTableConfig() {
    let columns = [
      ['sno', 5],
      ['complaint_title', 20],
      ['employee', 10],
      ['requester', 5],
    ];
    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }
  getDocumentTableConfig() {
    let columns = [
      ['sno', 5],
      ['doc_title', 40],
      // ['authors', 20],
      ['employee', 20],
      ['requester', 5],
    ];
    let table_body_config = this.getTableColumns(columns);
    return table_body_config;
  }

  createTable() {
    let table_config: SmartTableMainConfig = {
      name: 'Telephone-complaints',
      title: 'Vendors Details',
      table_class: 'smart-responsive',
      download: false,
      showentries: true,
      currentpage: false,
      pagination: true,
      buttons_tempalte: this.actionsTemplate,
      colsearch: false,
      search: true,
      showingentries: true,
      showEntriesClass: 'is-4',
      search_bar_placeholder: 'Search Complaint',
      searchBarClass: 'col-4 ',
      buttonBarClass: 'col-4 d-flex justify-content-end',
      no_results: {
        title: 'No Record Found',
        sub_title: '',
        icon: 'fa fa-user',
      },
    };

    this.tableConfigNew = {
      tableconfig: table_config,
      config: this.getTableConfig(),
      // filterConfig: this.getFilterConfig(),
      // filterData: {
      //   from_date: this.common.addDays(-30),
      //   to_date: this.common.currentDate(),
      // },
    };
    console.log('table config ', this.tableConfigNew);
  }
}
