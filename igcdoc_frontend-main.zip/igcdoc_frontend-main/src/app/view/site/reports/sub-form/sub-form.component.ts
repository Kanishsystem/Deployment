import { Component } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-sub-form',
  templateUrl: './sub-form.component.html',
  styleUrls: ['./sub-form.component.css'],
})
export class SubFormComponent {
  form: FormGroup;

  constructor(private fb: FormBuilder) {
    this.form = this.fb.group({
      sub_data: this.fb.array([this.createPersonnelGroup()]),
    });
  }

  get sub_data(): FormArray {
    return this.form.get('sub_data') as FormArray;
  }

  createPersonnelGroup(): FormGroup {
    return this.fb.group({
      name_of_personnel: ['', Validators.required],
      tld_no: [''],
      drd_no: [''],
      planned_exposure: [''],
      dose_as_per: [''],
    });
  }

  addRow(): void {
    this.sub_data.push(this.createPersonnelGroup());
  }

  removeRow(index: number): void {
    this.sub_data.removeAt(index);
  }

  /** Parent will call this */
  public getFormValue(): any {
    return this.form.valid ? this.form.value : null;
  }

  /** Optional: form validity check */
  public isFormValid(): boolean {
    return this.form.valid;
  }
}
