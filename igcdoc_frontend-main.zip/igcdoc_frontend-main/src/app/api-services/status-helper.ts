
export const DOC_STATUS = [
    { comp: "5", tagClass: "is-link is-dark ", tagText: "Submitted !  Waiting For Approval", value:5,label:"Submitted!"},
    { comp: "15", tagClass: "is-link is-success ", tagText: "Completed", value:15,label:"Completed"},
    { comp: "6", tagClass: "is-link is-dark ", tagText: "Submitted", value:5,label:"Submitted"},
    { comp: "10", tagClass: "is-link is-dark ", tagText: "Submitted", value:10,label:"Submitted"},
    { comp: "11", tagClass: "is-link is-dark ", tagText: "Submitted", value:5,label:"Submitted"},
]