export const environment = {
    production: true,
  //  BASE_API_URL : ["http://localhost:8080/softdigisolutions/sds_igcdoc_backend/api/"],
    BASE_API_URL : ["api/"],
    ENCRYPT_KEY : "U2FsdGVkX19UaF+q3A91+oCYbkRbDQXmRlCI5hOha0s=",
    RES_REQ_SECURITY :  false,
    protocol: 'http://',
}