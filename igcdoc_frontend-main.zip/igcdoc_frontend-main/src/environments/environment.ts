export const environment = {
  production: false,
  //  BASE_API_URL : ["http://igcdoc.softdigisolutions.com/api/"],
  //BASE_API_URL : ["http://igcdoc.softdigisolutions.com/igcardoc_backend/api/"],
 // BASE_API_URL: ['http://192.168.1.39:8080/softdigisolutions/sds_igcdoc_backend/api/'],
  //  BASE_API_URL : ["http://localhost:8080/api/"],

  BASE_API_URL: ['https://igcdoc.tthefl.com/api/'],
 // BASE_API_URL : ["http://192.168.1.34/softdigisolutions/sds_igcdoc_backend/api/"],
  ENCRYPT_KEY: 'U2FsdGVkX19UaF+q3A91+oCYbkRbDQXmRlCI5hOha0s=',
  RES_REQ_SECURITY: false,
};
// "http://ebookapi.softdigisolutions.cm/api/", http://134.209.232.225:8080/
// igcdoc.softdigisolutions.com
